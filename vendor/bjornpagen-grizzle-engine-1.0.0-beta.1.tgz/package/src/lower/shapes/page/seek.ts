import { appendNonEmpty, isNonEmpty, mapNonEmpty } from "#compiler/core/nonempty.ts"
import { type Direction, opposite } from "#compiler/core/order.ts"
import { type OperatorNames, operatorSchemaOf, typedCompare } from "#compiler/ir/compare.ts"
import type { PageFill, SizeFill } from "#compiler/ir/products.ts"
import type { CompletedOrder, Heading, OrderKey } from "#compiler/ir/rel.ts"
import type { ScalarType } from "#compiler/ir/scalar.ts"
import {
	type ColumnMap,
	columnIn,
	type StatementParams
} from "#compiler/lower/conservative/context.ts"
import type { PageParamSlot } from "#compiler/lower/conservative/types.ts"
import { columnType } from "#compiler/runtime/lower/columns.ts"
import type { Expr, OrderItem, TypeRef } from "#compiler/sql/ast.ts"
import { and, asc, binary, desc, lit, or, row, slotParam, types } from "#compiler/sql/build.ts"

/**
 * The four request shapes: { first }, { first, after }, { last }, { last, before }. Each is its own
 * compiled variant, so no variant has a nullable cursor slot.
 */
const pageVariants = ["first", "after", "last", "before"] as const
export type PageVariant = (typeof pageVariants)[number]

/** The requests of no anchor, whose statements seek nothing. */
export type PlainVariant = Extract<PageVariant, "first" | "last">

/** The requests anchored at a cursor's boundary, whose statements seek past it. */
export type AnchoredVariant = Exclude<PageVariant, PlainVariant>

/**
 * The page fills a variant's statements hold: a plain request's are its sizes alone, so no binding of one reads a
 * boundary; an anchored request's are its sizes and its comparators' boundaries.
 */
export interface VariantFill {
	readonly first: SizeFill
	readonly after: PageFill
	readonly last: SizeFill
	readonly before: PageFill
}

/** The order a variant fetches in: the declared order for first and after, every direction reversed for last and before. */
export type PageDirection = "forward" | "backward"

export const variantDirection = (variant: PageVariant): PageDirection =>
	variant === "first" || variant === "after" ? "forward" : "backward"

/**
 * The bounded existence probes of the opposite flag: whether D holds a tuple at or before, or at or after, the request's
 * anchor. The anchor alone decides the flag, so the probe needs no delivered row:
 *
 * Write A for the anchor, < for the declared order, which is total on D's comparison tuples, and E for the page's first
 * edge, the least t of D with A < t. For an after request, hasPreviousPage is "some t of D has t < E". If t < E, then
 * not A < t, since E is the least tuple of D after A; so t <= A, the order being total. If t <= A, then t < E, since
 * A < E. So "some t of D has t < E" is exactly "some t of D has t <= A", the atOrBefore probe on the anchor. An empty
 * page has no E, and every t of D has t <= A, so its flag is the same probe. A before request is the mirror image:
 * hasNextPage is the atOrAfter probe on the anchor. The anchor need not be a tuple of D.
 */
export const probeKinds = ["atOrBefore", "atOrAfter"] as const
export type ProbeKind = (typeof probeKinds)[number]

/**
 * Which side of the boundary a predicate selects, and whether the boundary tuple itself qualifies.
 *
 * The seek of a keyset page.
 *
 * A cursor names a strict boundary in the completed total order (k1, ..., km) with directions d1, ..., dm. "After c" is
 * lexicographically later in the declared order:
 *
 *   (k1 follows c1) OR (k1 = c1 AND k2 follows c2) OR ... OR (k1 = c1 AND ... AND k(m-1) = c(m-1) AND km follows cm)
 *
 * where follows is native > for an ascending key and native < for a descending one; "before c" reverses every
 * inequality. Every comparison is between non-null values, so the predicate is a plain
 * Boolean with no NULL branch.
 *
 * When every key has the same direction, the predicate is the equivalent native row comparison, `(k1, ..., km) >
 * (c1, ..., cm)` for ascending keys and `<` for descending ones: PostgreSQL turns a row comparison into an index
 * condition, while it applies the OR expansion as a filter over the index prefix, discarding every entry before the
 * boundary. A single key is the plain comparison. Mixed directions keep the
 * expansion: a row comparison compares every member with one operator, so it cannot express them, and no
 * arithmetic negation fakes a reversed key.
 *
 * Every comparison is at the operator its key's type resolves (ir/compare.ts typedCompare): over a vector the
 * extension's qualified operator, since a role's search_path never holds the extension schema. A row comparison
 * resolves each member's operator by name, so a tuple that holds a key of a qualified operator keeps the expansion.
 *
 * The inclusive forms "at or after c" and "at or before c" serve the flags of an empty page: the strict
 * predicate or the whole tuple equal, as one native row comparison `>=` / `<=` when the directions agree. The
 * zero-column relation orders by the empty comparison tuple: nothing is strictly after or before it, and
 * it is at or after itself.
 *
 * Each boundary value is one placeholder, cast to its comparator's base type: a comparison parameter casts to the base
 * type, so the indexed column is never cast, and a contract field
 * compares as its base. The values are the cursor's canonical parameter-codec texts, bound byte for byte as captured.
 */
export interface Seek {
	readonly side: "follows" | "precedes"
	readonly inclusive: boolean
}

/** The seek of an anchored request: strictly past its anchor in its fetch direction. */
export const anchoredSeek = (variant: AnchoredVariant): Seek => {
	switch (variant) {
		case "after":
			return { side: "follows", inclusive: false }
		case "before":
			return { side: "precedes", inclusive: false }
	}
}

export const probeSeek = (kind: ProbeKind): Seek => {
	switch (kind) {
		case "atOrBefore":
			return { side: "precedes", inclusive: true }
		case "atOrAfter":
			return { side: "follows", inclusive: true }
	}
}

/**
 * One position of the completed order as a cursor compares it: a field of the delivered heading, its direction, and
 * its type (the shape codec/cursor's CursorComparator reads).
 */
export interface PageComparator {
	readonly field: string
	readonly direction: Direction
	readonly type: ScalarType
}

/**
 * The comparators of a completed order over a delivered heading: exactly its keys, in order. The completion made the
 * order total on the result (logical/order.ts), so these keys identify a tuple and are the whole cursor
 * tuple; ORDER BY columns a lowering appends where the physical facts do not prove the keys total never break a tie
 * among them.
 */
export const pageComparators = (
	order: CompletedOrder,
	heading: Heading
): ReadonlyArray<PageComparator> =>
	order.keys.map((k: OrderKey) => ({
		field: k.column,
		direction: k.dir,
		type: columnType(heading, k.column)
	}))

/** A new placeholder of `params` the page request fills with `fill`, cast to `sqlType`. */
const pageParam = <F extends PageFill>(
	params: StatementParams<PageParamSlot<F>>,
	fill: F,
	sqlType: TypeRef
): Expr =>
	slotParam(
		params.own((number): PageParamSlot<F> => ({
			kind: "page",
			placeholder: "value",
			number,
			fill
		})),
		sqlType
	)

/**
 * The size placeholders of one statement, its limit and its size, each allocated into that statement's parameter list
 * (its delivery's params once the statement began) by `allocate` at its first use, after the statement's own
 * parameters, and read by every later one: every request's statement holds them, a plain request's alone.
 */
class SizeSlots {
	readonly #allocate: (fill: SizeFill) => Expr
	#limit: Expr | undefined
	#size: Expr | undefined

	constructor(allocate: (fill: SizeFill) => Expr) {
		this.#allocate = allocate
	}

	/**
	 * The limit placeholder, `$n::bigint`: the requested size plus one. A page size is any safe integer of at least 1,
	 * and every safe integer and its successor are bigint values, which LIMIT takes.
	 */
	limit(): Expr {
		this.#limit ??= this.#allocate({ kind: "limit" })
		return this.#limit
	}

	/** The size placeholder, `$n::bigint`: the most rows the page delivers, any safe integer of at least 1. */
	size(): Expr {
		this.#size ??= this.#allocate({ kind: "size" })
		return this.#size
	}
}

/**
 * The boundary placeholders of an anchored request's or a probe's statement, one per comparator, each cast to its
 * comparator's base type: the first seek allocates them into the statement's parameter list, in comparator order, and
 * every later seek of the statement reads the same ones.
 */
class BoundarySlots {
	readonly #params: StatementParams<PageParamSlot>
	readonly #typeRef: (t: ScalarType) => TypeRef
	readonly #comparators: ReadonlyArray<PageComparator>
	#boundaries:
		| ReadonlyArray<{ readonly comparator: PageComparator; readonly boundary: Expr }>
		| undefined

	constructor(
		params: StatementParams<PageParamSlot>,
		typeRef: (t: ScalarType) => TypeRef,
		comparators: ReadonlyArray<PageComparator>
	) {
		this.#params = params
		this.#typeRef = typeRef
		this.#comparators = comparators
	}

	/** The seek keys over the delivered columns `map`: each comparator's column against its boundary value. */
	seekKeys(map: ColumnMap): ReadonlyArray<SeekKey> {
		this.#boundaries ??= this.#comparators.map((comparator, position) => ({
			comparator,
			boundary: pageParam(
				this.#params,
				{ kind: "boundary", position, field: comparator.field },
				this.#typeRef(comparator.type)
			)
		}))
		return this.#boundaries.map(({ comparator, boundary }) => ({
			direction: comparator.direction,
			type: comparator.type,
			column: comparatorColumn(map, comparator),
			boundary
		}))
	}
}

/** An anchored statement's seek and the boundary placeholders it compares against. */
export interface Anchor {
	readonly seek: Seek
	readonly boundaries: BoundarySlots
}

/** A request statement's page placeholders: its sizes, and, for an anchored request, its anchor. */
export interface RequestSlots {
	readonly sizes: SizeSlots
	readonly anchor: Anchor | undefined
}

/** A plain request's statement's page placeholders over its parameter list `params`: its sizes alone. */
export const plainSlots = (params: StatementParams<PageParamSlot<SizeFill>>): RequestSlots => ({
	sizes: new SizeSlots((fill) => pageParam(params, fill, types.bigint)),
	anchor: undefined
})

/**
 * An anchored request's or a probe's statement's page placeholders over its parameter list `params`: its sizes, and its
 * seek `seek` against one boundary per comparator, typed by `typeRef`.
 */
export const anchoredSlots = (
	params: StatementParams<PageParamSlot>,
	typeRef: (t: ScalarType) => TypeRef,
	comparators: ReadonlyArray<PageComparator>,
	seek: Seek
): RequestSlots & { readonly anchor: Anchor } => ({
	sizes: new SizeSlots((fill) => pageParam(params, fill, types.bigint)),
	anchor: { seek, boundaries: new BoundarySlots(params, typeRef, comparators) }
})

/**
 * One position of a seek: its direction, its comparator's type, the delivered column it reads, and the boundary value
 * it compares that column against.
 */
export interface SeekKey {
	readonly direction: Direction
	readonly type: ScalarType
	readonly column: Expr
	readonly boundary: Expr
}

/** The delivered column of `map` a comparator reads. */
export const comparatorColumn = (map: ColumnMap, comparator: PageComparator): Expr =>
	columnIn(map, comparator.field)

/** Whether a seek on these keys is one native row comparison: every key in one direction, and every key's operators
 * builtin, which a row comparison resolves by name. */
const isRowSeek = (keys: ReadonlyArray<SeekKey>, names: OperatorNames): boolean =>
	keys.every(
		(k) => k.direction === keys[0]?.direction && operatorSchemaOf(names, k.type) === undefined
	)

/** The operator by which a key on `side` of its boundary value compares, strictly or inclusively. */
const operator = (direction: Direction, seek: Seek): ">" | "<" | ">=" | "<=" => {
	const greater = (direction === "asc") === (seek.side === "follows")
	return greater ? (seek.inclusive ? ">=" : ">") : seek.inclusive ? "<=" : "<"
}

/**
 * The seek predicate of `keys` against their boundary values; undefined when every tuple qualifies (the inclusive seek
 * of the empty comparison tuple).
 */
export const seekPredicate = (
	keys: ReadonlyArray<SeekKey>,
	seek: Seek,
	names: OperatorNames
): Expr | undefined => {
	if (!isNonEmpty(keys)) {
		return seek.inclusive ? undefined : lit.bool(false)
	}
	const [first] = keys
	const compare = (op: ">" | "<" | ">=" | "<=" | "=", k: SeekKey): Expr =>
		typedCompare(op, k.type, k.column, k.boundary, names)
	if (keys.length === 1) {
		return compare(operator(first.direction, seek), first)
	}
	if (isRowSeek(keys, names)) {
		return binary(
			operator(first.direction, seek),
			row(mapNonEmpty(keys, (k) => k.column)),
			row(mapNonEmpty(keys, (k) => k.boundary))
		)
	}
	const equal = (k: SeekKey): Expr => compare("=", k)
	const terms = mapNonEmpty(keys, (k, j) =>
		and(
			appendNonEmpty(
				keys.slice(0, j).map(equal),
				compare(operator(k.direction, { side: seek.side, inclusive: false }), k)
			)
		)
	)
	return or(seek.inclusive ? appendNonEmpty(terms, and(mapNonEmpty(keys, equal))) : terms)
}

/** ORDER BY items with every direction reversed: last and before reverse every sort direction. */
export const reversedOrder = (items: ReadonlyArray<OrderItem>): ReadonlyArray<OrderItem> =>
	items.map((item) => (item.direction === "DESC" ? asc(item.expr) : desc(item.expr)))

/**
 * A completed order with every direction reversed: the fetch order of a backward variant, which a heading-group merge
 * reads.
 */
export const reversedCompletedOrder = (order: CompletedOrder): CompletedOrder => ({
	keys: order.keys.map((k) => ({ column: k.column, dir: opposite(k.dir) }))
})
