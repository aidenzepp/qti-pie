import { appendAll } from "#compiler/core/array.ts"
import { catchRefusal, Refusal } from "#compiler/core/canonical.ts"
import { type CompileError, malformedDescription } from "#compiler/core/errors.ts"
import {
	censusOf,
	DeclaredNamespace,
	type Identity,
	identifierOf,
	maxIdentifierBytes
} from "#compiler/core/identity.ts"
import type { IdentityKind } from "#compiler/core/ids.ts"
import { SourceLoc } from "#compiler/core/loc.ts"
import { compareStrings } from "#compiler/core/order.ts"
import * as Result from "#compiler/core/result.ts"
import { type Codebook, firstCodebook } from "#compiler/ir/codes.ts"
import type { IndexRequest, InstallationManifest } from "#compiler/ir/products.ts"
import { addAdvanceFunctions } from "#compiler/physical/ddl/advance.ts"
import { addClosedRelations, addRosters } from "#compiler/physical/ddl/constants.ts"
import { InstallBuilder, type InstallSettings } from "#compiler/physical/ddl/context.ts"
import {
	addContextContractDomains,
	addContractDomains,
	addTextDomains,
	type TextDomain
} from "#compiler/physical/ddl/domains.ts"
import { addWorlds, type InstalledLogin } from "#compiler/physical/ddl/roles.ts"
import { addRules } from "#compiler/physical/ddl/rules.ts"
import { addTables } from "#compiler/physical/ddl/tables.ts"
import {
	type PlannedIndex,
	planIndexes,
	reverseRequests
} from "#compiler/physical/indexes/engine.ts"
import { commentsOf } from "#compiler/physical/install/comments.ts"
import type { InstallExtension } from "#compiler/physical/install/extension.ts"
import {
	freshPlanSettings,
	type InstallBasis,
	installBasis,
	type InstallPlan,
	planInstallation
} from "#compiler/physical/install/plan.ts"
import { refinedConstantsExtension } from "#compiler/physical/refined/constants.ts"
import { addSpanStorage } from "#compiler/physical/span/storage.ts"
import { planStatistics, type StatisticsRequest } from "#compiler/physical/statistics/statistics.ts"
import { type Owned, ownedIdentities, rostersOf } from "#compiler/schema/own.ts"
import type { SqlStatement } from "#compiler/sql/ast.ts"

/** The settings the installation runs under (`InstallSettings`: the owner a fresh-install script names, undefined for
 * a migration; the PostgreSQL schema; the vector extension's and btree_gist's schemas; the logins over the schema), the
 * extensions it runs, in order, and the codes of the installation it compiles for. Index requests beyond the
 * law-maintenance ones come from an extension's contribution, as the workload's do (`workloadExtension`). */
export interface InstallOptions extends InstallSettings {
	readonly extensions: ReadonlyArray<InstallExtension>
	/** The installation's codes: every code a literal, a constant or a domain's CHECK holds, and every bit(n) width. */
	readonly codes: Codebook
}

/** The options of a fresh installation of `owned` under its declared name's identity, owned.installation, with the
 * vector extension in vector_ext and btree_gist in public (the local cluster's), no login, no extension beyond the
 * built-in ones, and the first codebook, each roster's handles numbered from 0 with no hole, as `owner` names it. A
 * caller that targets another schema, installs logins, adds extensions or compiles for an installation with a history
 * of codes states them over these. */
export const installOptions = (owned: Owned, owner: string | undefined): InstallOptions => {
	const fresh = freshPlanSettings(owned)
	return {
		owner,
		levels: fresh.levels,
		vectorSchema: fresh.vectorSchema,
		extensionSchema: "public",
		logins: fresh.logins,
		extensions: [],
		codes: firstCodebook(rostersOf(owned))
	}
}

/** An installation: its plan (physical/install/plan.ts InstallPlan), under the settings it was admitted with, and the
 * objects built from it. */
export interface Installation extends InstallPlan {
	readonly settings: InstallSettings
	readonly manifest: InstallationManifest<SqlStatement>
	/** The install script: every object's DDL in install order, then the PUBLIC revokes, the logins' defaults and every
	 * installed object's COMMENT. */
	readonly statements: ReadonlyArray<SqlStatement>
	readonly textDomains: ReadonlyArray<TextDomain>
	readonly indexes: ReadonlyArray<PlannedIndex>
	/** The logins and their roles, in name order. */
	readonly worlds: ReadonlyArray<InstalledLogin>
	/** Every identity the installation named an object by, ownership's, the law model's and the installer's, each as
	 * often as it was minted: the census its comments passed. */
	readonly identities: ReadonlyArray<Identity<IdentityKind>>
	/** What this installation leaves to other packages' extensions: its materialized derived relations no extension
	 * installs. */
	readonly deferred: {
		readonly derivedRelations: ReadonlyArray<string>
	}
}

/**
 * A schema identifier the installation may create: a plain lowercase identifier, at most maxIdentifierBytes, outside
 * pg_.
 */
const admittedSchema = (name: string): boolean => {
	if (name.length === 0 || name.length > maxIdentifierBytes.value || name.startsWith("pg_")) {
		return false
	}
	for (let i = 0; i < name.length; i++) {
		const ch = name.charAt(i)
		const lower = ch >= "a" && ch <= "z"
		if (!(lower || ch === "_" || (i > 0 && ch >= "0" && ch <= "9"))) {
			return false
		}
	}
	return true
}

/** The installation of an owned schema, under the policy it was owned under, for the installation that holds
 * `options.codes`: the obligation graph of every native object, each with its DDL, its reasons and its phase, in a
 * deterministic install order; the manifest; the planned indexes with their merged provenance; and the install script,
 * its statements as SQL trees, printed only where they are sent or drafted. It is pure: no database, no clock, no file.
 *
 * The steps follow the dependency order: the namespace and the refusal function every write statement that can refuse
 * raises through; the isolation default and guard; each roster's names constant and domains and each closed
 * relation's constants (physical/ddl/constants.ts), the structural text domains and the contract domains;
 * the tables with their identities; the tags, keys, CHECKs and references the law model specialized; the shape, width
 * and contract-endpoint CHECKs of every span column (`addSpanStorage`), which every installation carries because a span's
 * storage is never optional; the validation of every closed payload with a nontrivial refinement
 * (`refinedConstantsExtension`), which every installation carries because the compiler relies on a closed fact's
 * membership only once PostgreSQL has validated it; then the caller's extensions; then the law-maintenance and workload
 * indexes, deduplicated against the key indexes; then, in Publish, the worlds: the logins, their roles with their
 * schemas, views, grants and policies, the logins' defaults, and the PUBLIC revokes. An extension of btree_gist precedes
 * any span key or GiST index with a scalar component.
 *
 * Every constraint it installs, with the law a violation reports, is its plan's (InstallPlan.constraintLaws), which no
 * extension adds to. A derived relation that no extension claims is
 * reported in `deferred`: the natives are installed, and the caller decides whether the installation is complete
 * enough for its purpose.
 *
 * The script is one transaction run as the migration identity, the owner; on a fresh schema every table is empty, so
 * ordinary CREATE INDEX serves. */
export const compileInstallation = (
	owned: Owned,
	options: InstallOptions
): Result.Result<Installation, CompileError> =>
	Result.flatMap(installBasis(owned, options.codes), (basis) => installationOver(basis, options))

/** The settings of `options`, refused unless every schema identifier it names is one the installation may create, the
 * installed schema's being the naming door's, the extension schema lies outside the installed schema, which it outlives,
 * every login is over the installed schema, and the logins' and their roles' names convert apart: each one's
 * PostgreSQL role is `<schema>__<name>`, so they are one namespace of declared names (IdentifierCollision). */
const admittedSettings = (
	owned: Owned,
	options: InstallSettings
): Result.Result<InstallSettings, CompileError> => {
	const at = SourceLoc(`installation of schema ${owned.name}`, [])
	const settings: InstallSettings = {
		owner: options.owner,
		levels: options.levels,
		vectorSchema: options.vectorSchema,
		extensionSchema: options.extensionSchema,
		logins: options.logins
	}
	for (const [what, name] of [
		...(settings.owner === undefined ? [] : [["owner", settings.owner] as const]),
		["vector schema", settings.vectorSchema],
		["extension schema", settings.extensionSchema]
	] as const) {
		if (!admittedSchema(name)) {
			return Result.err(
				malformedDescription(
					at,
					`an admitted ${what} identifier; ${JSON.stringify(name)} is not one`
				)
			)
		}
	}
	if (settings.levels.length !== owned.levels.length) {
		return Result.err(
			malformedDescription(
				at,
				`a PostgreSQL schema for each of the ${owned.levels.length} levels of ${owned.name}; ${settings.levels.length} are given`
			)
		)
	}
	if (settings.levels.some((l) => identifierOf(l) === settings.extensionSchema)) {
		return Result.err(
			malformedDescription(
				at,
				"an extension schema outside the installed schemas, which outlives them"
			)
		)
	}
	const roles = new DeclaredNamespace(`the installation ${owned.name}'s login and role`)
	for (const login of settings.logins) {
		const level = owned.levels[login.base.levels.length - 1]
		if (
			level === undefined ||
			level.fingerprint !== login.base.fingerprint ||
			level.name !== login.base.name
		) {
			return Result.err(
				malformedDescription(
					login.loc,
					`a login over a level of the installed schema ${owned.name}; login ${login.name} is over ${login.base.name}`
				)
			)
		}
		const named = [
			roles.declare(login.name, "login", login.loc),
			...login.roles.map((r) => roles.declare(r.name, "role", r.loc))
		]
		for (const n of named) {
			if (!n.ok) {
				return n
			}
		}
	}
	return Result.ok(settings)
}

/**
 * The installation over a basis (installBasis) under the settings and extensions of `options`, whose codes are the
 * basis's (compileInstallation): its settings admitted, its plan (planInstallation), then its objects built from the
 * plan. The span CHECKs (`addSpanStorage`) and the closed facts' validation (`refinedConstantsExtension`) precede the
 * caller's extensions, each once: a caller that lists one extension twice adds nothing twice.
 */
export const installationOver = (
	basis: InstallBasis,
	options: Omit<InstallOptions, "codes">
): Result.Result<Installation, CompileError> =>
	Result.flatMap(admittedSettings(basis.owned, options), (settings) =>
		Result.flatMap(planInstallation(basis, settings, options.extensions), (plan) =>
			catchRefusal((): Installation => {
				const { owned, model, closed } = basis
				const b = new InstallBuilder({
					owned,
					checked: plan.checked,
					model,
					names: plan.names,
					settings
				})
				const rosters = addRosters(b)
				addClosedRelations(b, closed)
				const domains = [
					...rosters.flatMap((r) =>
						r.bits === undefined ? [r.domain.name] : [r.domain.name, r.bits.domain.name]
					),
					...addTextDomains(b, plan.textPlans),
					...addContractDomains(b),
					...addContextContractDomains(b, plan.contextContracts)
				]
				const { keyIndexes, tables, sequences } = addTables(b)
				const advance = addAdvanceFunctions(b)
				const ruleRequests = addRules(b)
				addSpanStorage(b, plan.spans)

				const claimedDerived = new Set<string>()
				const extensionRequests: Array<IndexRequest> = []
				const statisticsRequests: Array<StatisticsRequest> = []
				for (const extension of new Set([refinedConstantsExtension, ...options.extensions])) {
					const contribution = extension.contribute(b)
					if (!contribution.ok) {
						throw new Refusal(contribution.error)
					}
					const c = contribution.value
					appendAll(extensionRequests, c.indexRequests)
					appendAll(statisticsRequests, c.statisticsRequests)
					for (const d of c.derivedRelations) {
						claimedDerived.add(d)
					}
				}

				const requests = [...reverseRequests(b), ...ruleRequests, ...extensionRequests]
				const indexes = planIndexes(b, keyIndexes, requests)
				if (!indexes.ok) {
					throw new Refusal(indexes.error)
				}
				planStatistics(b, statisticsRequests)

				const worlds = addWorlds(b, advance, { tables, sequences, domains }, plan.logins)
				const identities = [...ownedIdentities(owned), ...model.identities, ...b.named()]
				const census = censusOf(identities)
				if (!census.ok) {
					throw new Refusal(census.error)
				}
				const ordered = b.graph.manifest({
					roleDefaults: worlds.roleDefaults,
					publicRevokes: worlds.publicRevokes
				})
				const created = ordered.objects.flatMap((o) => o.ddl)
				const comments = commentsOf(created, census.value)
				const manifest = { ...ordered, comments }
				const statements = [
					...created,
					...worlds.publicRevokes,
					...worlds.roleDefaults,
					...comments
				]
				const derived = Object.values(owned.relations)
					.filter((r) => r.kind === "derived" && r.view.kind === "materialized")
					.map((r) => r.name)
				return {
					...plan,
					settings,
					manifest,
					statements,
					textDomains: plan.textPlans.map((p) => p.domain),
					indexes: indexes.value,
					worlds: worlds.worlds,
					identities,
					deferred: {
						derivedRelations: derived.filter((d) => !claimedDerived.has(d)).toSorted(compareStrings)
					}
				}
			})
		)
	)
