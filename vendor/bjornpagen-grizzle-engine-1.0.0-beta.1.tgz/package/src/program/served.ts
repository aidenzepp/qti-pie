import { requireGet } from "#compiler/analysis/logical/get.ts"
import type { CursorGeneration } from "#compiler/codec/cursor/identity.ts"
import type { DecoderForm, RowDecoder } from "#compiler/core/decoder.ts"
import type { Isolation } from "#compiler/core/isolation.ts"
import { SourceLoc } from "#compiler/core/loc.ts"
import { isList } from "#compiler/core/record.ts"
import type { Codebook } from "#compiler/ir/codes.ts"
import type { QueryDesc } from "#compiler/ir/desc.ts"
import type { PageFill } from "#compiler/ir/products.ts"
import { Roster } from "#compiler/ir/scalar.ts"
import type { PageStatementSlot } from "#compiler/lower/conservative/types.ts"
import type { SentStatement } from "#compiler/lower/shapes/index.ts"
import type {
	PageProbeProgram,
	PageProgram,
	PageRequestProgram,
	PageTemplate
} from "#compiler/lower/shapes/page/compile.ts"
import type { PageVariant, ProbeKind } from "#compiler/lower/shapes/page/seek.ts"
import { sentSpec } from "#compiler/lower/template.ts"
import { loginStartupOptions } from "#compiler/physical/ddl/roles.ts"
import type { QueryTemplate } from "#compiler/program/compile.ts"
import { pageStatementSlotOf } from "#compiler/runtime/lower/slots.ts"
import { CompilePatterns } from "#compiler/scalar/regex/patterns.ts"
import type {
	ServedPage,
	ServedPageProbe,
	ServedPageProgram,
	ServedPageRequest,
	ServedRead,
	ServedRoleForm,
	ServedSession,
	ServedVariants
} from "#compiler/served/forms.ts"
import { servedHeading, servedProgram, servedSource } from "#compiler/served/read.ts"
import { servedSpine } from "#compiler/served/spine.ts"
import { emitText } from "#compiler/sql/emit.ts"
import { emptyNameMap } from "#compiler/sql/naming.ts"

/**
 * A query compiled for a role's rows, served (served/forms.ts ServedRead): its declared parameters, its artifact and
 * delivered spine (served/read.ts), its records' decoder, and whether get may read it, its template's analyzed root
 * proved at most one row per parameter binding (analysis/logical/get.ts requireGet).
 */
export const servedRead = (
	template: QueryTemplate,
	desc: QueryDesc,
	decoder: RowDecoder<unknown>
): ServedRead => ({
	params: template.params,
	source: servedSource(template.run),
	spine: servedSpine(desc),
	decoder: decoder.form,
	getEligible: requireGet(template.analyzed.roots[0], SourceLoc("reader.get", [])).ok
})

/**
 * A page's program as the runtime runs it: its statement's spec, and its large form's, emitted under the codes
 * `codes`, and its parts.
 */
const servedPageProgram = <F extends PageFill>(
	program: PageProgram<F>,
	codes: Codebook
): ServedPageProgram<F> => {
	const slotOf = pageStatementSlotOf(codes, new CompilePatterns())
	const { statement, parts, roots } = program
	const spec = (form: SentStatement<PageStatementSlot<F>>) => sentSpec(form, parts, roots, slotOf)
	const forms = statement.forms
	return servedProgram({
		statement: {
			params: statement.params,
			forms:
				forms.kind === "one"
					? forms
					: {
							kind: "chosen",
							choices: forms.choices,
							large: { statement: { params: forms.large.params }, spec: spec(forms.large) }
						},
			spec: spec(statement)
		},
		parts,
		roots
	})
}

/**
 * An ordered query's page, served (served/forms.ts ServedPage): its order, comparators and heading, each request's and
 * probe's program with its statement's spec emitted now under the installation's codes `codes`, and its cursor's
 * identity, the query's semantic fingerprint `query` and its schema's generation `generation`.
 */
export const servedPage = (
	page: PageTemplate,
	codes: Codebook,
	query: string,
	generation: CursorGeneration
): ServedPage => {
	const { requests, probes } = page.artifact
	const request = <V extends PageVariant>(
		program: PageRequestProgram<V>
	): ServedPageRequest<V> => ({
		...program,
		program: servedPageProgram(program.program, codes)
	})
	const probe = <K extends ProbeKind>(program: PageProbeProgram<K>): ServedPageProbe<K> => ({
		kind: program.kind,
		program: servedPageProgram(program.program, codes),
		column: { name: program.column.name, type: program.column.type }
	})
	return {
		order: page.order,
		comparators: page.comparators.map((c) => ({
			field: c.field,
			direction: c.direction,
			type: c.type
		})),
		heading: servedHeading(page.heading),
		requests: {
			first: request(requests.first),
			after: request(requests.after),
			last: request(requests.last),
			before: request(requests.before)
		},
		probes: { atOrBefore: probe(probes.atOrBefore), atOrAfter: probe(probes.atOrAfter) },
		query,
		generation
	}
}

/** A transaction's BEGIN at `isolation`, read only and read write. */
const beginAt = (isolation: Isolation): ServedSession["begin"][Isolation] => ({
	readOnly: emitText({ kind: "begin", isolation, readOnly: true }, emptyNameMap).text,
	readWrite: emitText({ kind: "begin", isolation, readOnly: false }, emptyNameMap).text
})

/**
 * The texts every session of a login sends that its file carries, emitted now (served/forms.ts ServedSession): the
 * startup options pinning its role's defaults (physical/ddl/roles.ts loginStartupOptions), each transaction's BEGIN at
 * each isolation level, read only or read write, and its COMMIT and ROLLBACK.
 */
export const servedSession: ServedSession = {
	startup: loginStartupOptions,
	begin: { serializable: beginAt("serializable"), readCommitted: beginAt("readCommitted") },
	commit: emitText({ kind: "commit" }, emptyNameMap).text,
	rollback: emitText({ kind: "rollback" }, emptyNameMap).text
}

/** The rosters a decoder form's columns read: a closed id's and a set's. */
const decoderRosters = (form: DecoderForm, out: Set<string>): void => {
	switch (form.kind) {
		case "record":
			for (const [, field] of form.fields) {
				if (field.kind === "column") {
					if (field.column.kind === "code" || field.column.kind === "bits") {
						out.add(field.column.roster)
					}
				} else {
					decoderRosters(field.child, out)
				}
			}
			return
		case "merge":
		case "oneOf":
			decoderRosters(form.first, out)
			decoderRosters(form.second, out)
			return
		case "arm":
			decoderRosters(form.parent, out)
			decoderRosters(form.child, out)
			return
		case "refused":
			return
	}
}

/**
 * Every Roster a served value holds, a type's among them, each container read once however many hold it. The walk is
 * the file writer's own (served/json.ts ServedWriter), which writes each Roster it meets wherever a form holds it as a
 * reference to the file's rosters, and a load revives each from them: so the rosters a load needs are exactly the ones
 * this reaches, whichever form holds a type, and no form added later can hold one the file lacks.
 */
const heldRosters = (value: unknown, out: Set<string>, seen: Set<object>): void => {
	if (typeof value !== "object" || value === null || seen.has(value)) {
		return
	}
	seen.add(value)
	if (value instanceof Roster) {
		out.add(value.closed)
		return
	}
	if (value instanceof Map) {
		for (const [k, v] of value) {
			heldRosters(k, out, seen)
			heldRosters(v, out, seen)
		}
		return
	}
	if (value instanceof Set || isList(value)) {
		for (const v of value) {
			heldRosters(v, out, seen)
		}
		return
	}
	for (const v of Object.values(value)) {
		heldRosters(v, out, seen)
	}
}

/**
 * The rosters a login's served roles read, by declared name: every Roster their forms hold (a closed id's or a set's
 * type), every closed id's and set's column their decoders read, and every roster a classifier names a domain of, one
 * typing a column its role's writes write (program/schema.ts raisableOf): the rosters whose codes the file carries
 * (served/forms.ts ServedFile rosters).
 */
export const servedRosters = (roles: ReadonlyArray<ServedRoleForm>): ReadonlySet<string> => {
	const out = new Set<string>()
	const seen = new Set<object>()
	for (const role of roles) {
		heldRosters(role, out, seen)
		for (const domain of role.refusals.laws.rosterDomains) {
			out.add(domain.roster)
		}
		for (const member of role.members) {
			switch (member.kind) {
				case "change":
					variantRosters(member.variants, out)
					break
				case "refresh":
					break
				case "read":
				case "paged":
				case "key":
					decoderRosters(member.read.decoder, out)
					break
			}
		}
	}
	return out
}

/** The rosters each change of a ChangeSet's variants reads in its reads decoder. */
const variantRosters = (variants: ServedVariants, out: Set<string>): void => {
	if (variants.kind === "change") {
		decoderRosters(variants.change.decoder, out)
		return
	}
	variantRosters(variants.holding, out)
	variantRosters(variants.lacking, out)
}
