import * as Arr from "effect/Array"
import type { ServerError } from "#adapter/errors/failures.ts"
import {
	type KeyLaws,
	type NativeLaws,
	type RosterDomain,
	reportedOwner
} from "#adapter/witness/keylaw.ts"
import type {
	AboveJudgement,
	AboveLaw,
	AboveRefusedLaw,
	ConcurrentChange,
	HostJudgement,
	KeyDecoder,
	LawDetail,
	Refused,
	RefusedLaw,
	RefusedLaws,
	Refuser,
	RefusingObject,
	Witness
} from "#compiler/plan/change.ts"
import type {
	DomainName,
	ConstraintName,
	ConstraintOwner,
	EntryName,
	LawId,
	RelationIdent,
	StoredRelationName
} from "#compiler/plan/common.ts"
import {
	defect,
	jsonText,
	readChangeDetail,
	readLawDetail,
	sqlstateClass,
	sqlstates,
	usesLaws
} from "#compiler/plan/runtime.ts"
import type { DescribedLaw } from "#compiler/plan/serve.ts"

/**
 * The ErrorResponse fields a violation is classified by: the identity fields PostgreSQL reports and grizzle controls
 * (errors/failures.ts ServerError, whose message the classifier never reads), each undefined when the server did not
 * report it. `detail` is read only from a write statement's refusal.
 */
type ViolationFields = Pick<
	ServerError,
	"sqlstate" | "constraint" | "schema" | "table" | "column" | "dataType" | "detail"
>

/**
 * Classifying one integrity violation or write refusal PostgreSQL reported into the laws it broke, as an outcome names
 * them (types/changeset RefusedLaw: each law as the schema states it, its identity, and the installed object that
 * refused it, the reported constraint or domain, or the write statement that raised it), and its witness, or a
 * concurrent change.
 *
 * The witness of `invariant-rejected` is built only from fields grizzle controls, for a statement or a COMMIT that
 * PostgreSQL refused, in the cases decided here:
 *
 * - SQLSTATE 23000 raised by a write statement's refusal (write/refusal.ts): the law's identifier as the constraint
 *   name and the DETAIL `k[...]`, the refused fact's relation with its values at the law's key fields, each the text of
 *   its column's result codec. The constraint must be a law of this installation; each key text converts through its
 *   column's codec, so the `key` witness carries the key values as the host types them.
 * - SQLSTATE 40Z01 raised by a write statement that met a concurrent change: the DETAIL `a[...]` names the
 *   TransientFailure reason and the relation, one of this installation's stored relations, and the outcome is that
 *   TransientFailure.
 * - SQLSTATE 42Z01 raised by a query entry's precheck (write/entry/precheck.ts): the entry's name as the constraint name.
 *   The outcome is `outside-world` for that entry, which carries no value, where it is an entry the role writes
 *   through (ReportedNames); any other name is no outcome.
 * - SQLSTATE 23514 on one of the installation's roster domains, the data type PostgreSQL reports: a roster's code
 *   domain admits exactly its live handles' codes, its bits domain exactly the sets of them, and grizzle's codec
 *   writes only live handles, so no statement grizzle sends can raise it. It is grizzle's own defect, never a law
 *   outcome: the domains are the codes' range proof and discharge no law, and a law over closed relations is a table
 *   CHECK named by its law on its table, which the next case reads.
 * - Any other class 23 SQLSTATE on a native constraint (23505 a key or a partial UNIQUE index, 23503 a foreign key,
 *   23514 a table CHECK, a contract's domain or a text refinement domain, 23P01 a span key) reports the laws its
 *   constraint name maps to under the owner PostgreSQL reports it on, the table, or the data type of a domain
 *   constraint, through the key-law map (keylaw.ts). The map holds native objects only, each under its table or
 *   domain, so a native violation is read under its owner alone. PostgreSQL
 *   states the violating key of a native violation only in its message and DETAIL prose, which for a CHECK holds the
 *   whole failing row with each value cut at 64 bytes, and the classifier reads neither: the witness is the host's
 *   (WrittenAt judge, runtime/write/witness.ts hostJudgement), the key of a fact the ChangeSet states for the failing
 *   statement that breaks what refused it, the table constraint or the domain's columns among the statement's tables,
 *   or `unreported` where it names none (hostJudgement). A table CHECK's refusal of a stated fact names `every` law
 *   of that table's CHECKs the fact, as its write fills it, breaks, in the schema's canonical order, whichever
 *   PostgreSQL tried first;
 *   where no stated fact breaks it, or the host leaves one of those CHECKs unjudged, the outcome names the CHECK
 *   PostgreSQL reported, `first`, since PostgreSQL tries a table's CHECKs in the order of their names. A table's CHECKs
 *   are the Db's own levels': a CHECK a level above installs there is neither judged nor counted. A domain's
 *   refusal of a stated fact names `every` law of the fact's columns it types whose values it refuses, a pattern's
 *   naming its relation and field, where the host judges each of those columns. A constraint of a level above the Db's
 *   own, which the map reads only where the Db's own tables name none, is refused `above`: its one law, as that level
 *   names it, and, where it is a row check over the relation of the table it stands on, what the host finds of its own
 *   CHECKs on the rows the ChangeSet states for the statement there (runtime/write/witness.ts aboveJudgement), with that
 *   finding's witness; of any other, a foreign key or a rule's trigger at COMMIT, nothing of its own laws.
 * - SQLSTATE 23502 on a generated column of the installation's: grizzle writes no NULL, so only the column's generation
 *   expression is NULL there, a closed read at a key its relation holds no row at, and the outcome names the generated
 *   field's law (types/changeset Law `generated`) with the host's witness of the stated fact whose term has no value.
 *   A 23502 on any other column, or one reporting no column, is no law outcome.
 *   The outcome names exactly the laws the violation breaks wherever what grizzle controls decides them, and `some` of
 *   the laws the violated object discharges where it cannot decide among several:
 *   - one law, for an object that discharges one: a key, a table CHECK, a contract's own domain, or a pattern's domain
 *     that types one column of the tables the failing statement writes;
 *   - a domain several columns share (a text domain types every field of its pattern, each its own law, and contracts
 *     of one definition share one): the laws of the columns it types in the tables the failing statement writes, which
 *     are the only values that statement coerced to it, or every column's where it writes none of them (a COMMIT, or a
 *     statement into a carrier), `some` of them where they are several and the host judges no stated fact whole;
 *   - `some` of the laws merged into one object, a family's axis foreign key carrying several containments: which pair
 *     of its columns failed is in PostgreSQL's DETAIL alone, which the classifier never reads.
 *
 * Every DETAIL read here is grizzle's own text, raised by grizzle's own statement, but it is the
 * database's answer: one the installation's encoding does not read is never a guess at a law or a reason, it is the
 * operational failure below.
 *
 * Everything else is not a law outcome, and the classifier answers `undefined` for the caller to map onto an
 * operational failure (an ExecutionFailure carrying the server's report): a SQLSTATE outside class 23, a violation
 * without a constraint name, a constraint no law of this installation names under the reported owner, a violation
 * reported in another schema than the installation's, a 23000 whose constraint is not a law the DETAIL's encoding
 * admits, and a DETAIL this installation's encoding does not read: none where one is raised, or one naming a relation,
 * field, law or reason that is not the installation's. Among the SQLSTATEs outside class 23 is the 21Z01 a read-back
 * statement raises when an attachment breaks the delivered type its evidence proved (write/refusal.ts): the database's
 * answer contradicting a proof, before COMMIT, so the write commits nothing and fails with the server's report, as a
 * read fails with it (wire/batch.ts asReadFailure). Aborts PostgreSQL raises itself (40001, 40P01, a unique violation
 * the failing statement lists as an abort) are decided before this classifier is consulted
 * (packages/grizzle/src/adapter/outcomes transientFailureOf).
 *
 * The classifier is the hook the transaction outcome mapping consumes (packages/grizzle/src/adapter/outcomes classifyServerError, whose
 * context every write entry fills from the layer's witness, packages/grizzle/src/adapter/apply/compile.ts): its answers are exactly that
 * mapping's `rejected` and `aborted` cases (ViolationClassifier), and `undefined` is its ExecutionFailure.
 *
 * A violation's meaning as a law outcome, a fact outside a query entry, a concurrent change a write statement met, or a
 * roster domain's refusal of a value grizzle wrote, which is grizzle's defect.
 */
export type Violation =
	| {
			readonly kind: "rejected"
			readonly refused: Refused
			readonly witness: Witness
	  }
	| { readonly kind: "outside"; readonly relation: EntryName }
	| { readonly kind: "aborted"; readonly reason: ConcurrentChange }
	| { readonly kind: "defect"; readonly domain: DomainName; readonly roster: RosterDomain }

/**
 * What the failing statement wrote: the stored relations it writes or casts its facts into, by declared name (none for
 * a COMMIT, a read-back or a statement that states no fact), and the host's judgement of a native refusal there, over
 * the facts the ChangeSet states for it (runtime/write/witness.ts hostJudgement): the witness of the first that breaks
 * the refuser, or unreported where none does, and which laws the refusal names.
 */
export interface WrittenAt {
	readonly relations: ReadonlyArray<StoredRelationName>
	readonly judge: (refuser: Refuser) => HostJudgement
	/**
	 * The host's judgement of its own CHECKs on the table `owner` over the facts the ChangeSet states for the failing
	 * statement, which a CHECK of a level above refused there (runtime/write/witness.ts aboveJudgement).
	 */
	readonly above: (owner: RelationIdent) => AboveJudgement
}

/** The hook: a violation's law outcome, or undefined when it is not one, raised by a statement that wrote `written`. */
export type ViolationClassifier = (
	failure: ViolationFields,
	written: WrittenAt
) => Violation | undefined

/** A roster's live codes as its domains admit them, each with its handle, and its holes: `0 "a", 2 "c"; holes 1`. */
const liveCodesText = (roster: RosterDomain): string => {
	const live: Array<string> = []
	const holes: Array<string> = []
	for (const [code, name] of roster.codec.names.entries()) {
		if (name === "") {
			holes.push(String(code))
		} else {
			live.push(`${code} ${jsonText(name)}`)
		}
	}
	return holes.length === 0
		? Arr.join(live, ", ")
		: `${Arr.join(live, ", ")}; holes ${Arr.join(holes, ", ")}`
}

/**
 * The defect a roster domain's violation is, raised at `at`, a statement of grizzle's or its COMMIT: the domain, its
 * roster and the codes it admits, which are every code grizzle's codec writes.
 */
export const rosterDomainDefect = (
	violation: Extract<Violation, { readonly kind: "defect" }>,
	at: string
): Error => {
	const { carrier, codec } = violation.roster
	const admits =
		carrier === "code"
			? `a live handle's code (${liveCodesText(violation.roster)})`
			: `a set of live handles' bits, bit(${codec.width}) with a 0 at every hole and every padding bit past code ${codec.size - 1} (${liveCodesText(violation.roster)})`
	return defect(
		`grizzle writes only live handles, and ${carrier === "code" ? "the code" : "the bits"} domain ${violation.domain} of roster ${codec.roster} admits ${admits}, yet ${at} raised 23514 on it`
	)
}

/** The write statement that raised a law it refused under its identity (write/refusal.ts). */
const byStatement: RefusingObject = Object.freeze({ kind: "statement" })

/**
 * The rejection of `law` by a write statement's refusal, from its DETAIL; undefined when the DETAIL names a relation,
 * field or key value that is not this installation's.
 */
const refusalRejection = (
	law: DescribedLaw,
	refusal: Extract<LawDetail, { readonly kind: "law" }>,
	decoder: KeyDecoder
): Violation | undefined => {
	const witness = decoder.fromRefusal(refusal.relation, refusal.key)
	return witness === undefined
		? undefined
		: {
				kind: "rejected",
				refused: {
					kind: "every",
					laws: [{ law: law.described, id: law.law, by: byStatement }]
				},
				witness
			}
}

/**
 * A concurrent change a write statement raised: its reason, at a stored relation of this installation; undefined for a
 * DETAIL that names no reason a write statement raises, or a relation `stored` does not hold, or none.
 */
const concurrentChange = (
	detail: string | undefined,
	stored: ReadonlySet<string>
): Violation | undefined => {
	const read = detail === undefined ? undefined : readChangeDetail(detail)
	return read === undefined || !stored.has(read.relation)
		? undefined
		: { kind: "aborted", reason: { _tag: read.reason, relation: read.relation } }
}

/** The installed object a native violation reports, `constraint` under `owner`, as an outcome names it. */
const nativeObject = (constraint: ConstraintName, owner: ConstraintOwner): RefusingObject =>
	owner.kind === "table"
		? { kind: "constraint", table: owner.name, name: constraint }
		: { kind: "domain", domain: owner.name, name: constraint }

/** The columns of the tables `written` a native violation's domain types: none for an object that types none. */
const coercedUses = (native: NativeLaws, written: ReadonlySet<RelationIdent>) =>
	native.kind === "domain" ? Arr.filter(native.uses, (use) => written.has(use.table)) : []

/**
 * The laws a native violation can name (see the header), each refused by `by`, the object that reported it: a domain's,
 * of the columns it types in the tables `written`, when it types any there, and of every column it types otherwise,
 * each law once; every law any other object discharges.
 */
const nativeLaws = (
	native: Extract<NativeLaws, { readonly kind: "object" | "domain" }>,
	written: ReadonlySet<RelationIdent>,
	by: RefusingObject
): Arr.NonEmptyReadonlyArray<RefusedLaw> => {
	const refused = (l: DescribedLaw): RefusedLaw => ({ law: l.described, id: l.law, by })
	switch (native.kind) {
		case "object":
			return Arr.map(native.laws, refused)
		case "domain": {
			const coerced = coercedUses(native, written)
			return Arr.map(
				usesLaws(Arr.isReadonlyArrayNonEmpty(coerced) ? coerced : native.uses),
				refused
			)
		}
	}
}

/**
 * The laws an object's refusal names where nothing grizzle holds decides among them: its one law, decided, or `some`
 * of its several, at least one of which the row broke.
 */
const objectRefused = (laws: Arr.NonEmptyReadonlyArray<RefusedLaw>): Refused => {
	const [first, ...rest] = laws
	const [second, ...more] = rest
	return second === undefined
		? { kind: "every", laws: [first] }
		: { kind: "some", laws: [first, second, ...more] }
}

/**
 * The laws a native refusal names, as the host judged it (runtime/write/witness.ts RefusedLaws): every law of its
 * table's CHECKs or of its domain's columns the stated row breaks; the CHECK PostgreSQL reported first, `broken`,
 * where no stated row breaks it or the host leaves one of its table's CHECKs unjudged; and for any other refusal the
 * laws its one object discharges that the statement can break, `broken`, decided where it is one.
 */
const refusedBy = (laws: RefusedLaws, broken: Arr.NonEmptyReadonlyArray<RefusedLaw>): Refused => {
	switch (laws.kind) {
		case "every":
			return { kind: "every", laws: laws.laws }
		case "first":
			return { kind: "first", laws: broken }
		case "object":
			return objectRefused(broken)
	}
}

/** The law of a level above PostgreSQL named, refused by the object `by` that reported it. */
const aboveRefused = (law: DescribedLaw<LawId, AboveLaw>, by: RefusingObject): AboveRefusedLaw => ({
	law: law.described,
	id: law.law,
	by
})

/** Nothing said of the Db's own laws: a refusal by a level above's object other than a CHECK on a table it wrote. */
const ownUnjudged: AboveJudgement = Object.freeze({ own: "unjudged" })

const unreported: Witness = Object.freeze({ kind: "unreported" })

/**
 * A refusal by `law`, of a level above, PostgreSQL named, beside what the host finds of its own CHECKs there (`own`):
 * every law of theirs the first stated row breaking one breaks, witnessed by that row, or none, or nothing said.
 */
const aboveRejection = (law: AboveRefusedLaw, own: AboveJudgement): Violation => {
	switch (own.own) {
		case "every": {
			const [first, ...rest] = own.laws
			return {
				kind: "rejected",
				refused: { kind: "above", own: "every", laws: [law, first, ...rest] },
				witness: own.witness
			}
		}
		case "none":
		case "unjudged":
			return {
				kind: "rejected",
				refused: { kind: "above", own: own.own, laws: [law] },
				witness: unreported
			}
	}
}

/**
 * A NOT NULL violation's law outcome: on a generated column of the installation's, the generated field's law, which
 * only its generation expression's NULL, a closed read at a key its relation holds no row at, breaks, since grizzle
 * writes no NULL; undefined on any other column, or none.
 */
const generatedViolation = (
	laws: KeyLaws,
	owner: ConstraintOwner | undefined,
	column: ViolationFields["column"],
	written: WrittenAt
): Violation | undefined => {
	if (owner?.kind !== "table" || column === undefined) {
		return undefined
	}
	const law = laws.generatedOf(owner.name, column)
	return law === undefined
		? undefined
		: {
				kind: "rejected",
				refused: { kind: "every", laws: [law] },
				witness: written.judge({ kind: "generated", table: owner.name, column }).witness
			}
}

/**
 * What a violation names the installation's relations by, as the server reports them: its stored relations, by declared
 * name, which a concurrent change's DETAIL names; and the query entries the role writes through, each by its name,
 * which a precheck's refusal reports as its constraint, so a name the role writes through no entry is no outcome.
 */
export interface ReportedNames {
	readonly stored: ReadonlySet<string>
	readonly entries: ReadonlyMap<string, EntryName>
}

/** The classifier of one installation's violations (see the header), whose relations it names are `names`. */
export const violationClassifier =
	(laws: KeyLaws, decoder: KeyDecoder, names: ReportedNames): ViolationClassifier =>
	(failure, written) => {
		if (failure.sqlstate === sqlstates.grizzleConcurrentChange) {
			return concurrentChange(failure.detail, names.stored)
		}
		if (failure.sqlstate === sqlstates.grizzleOutsideWorld) {
			const entry =
				failure.constraint === undefined ? undefined : names.entries.get(failure.constraint)
			return entry === undefined ? undefined : { kind: "outside", relation: entry }
		}
		if (sqlstateClass(failure.sqlstate) !== sqlstateClass(sqlstates.integrityConstraintViolation)) {
			return undefined
		}
		/**
		 * The reported table or data type names an object of the installation only when the reported schema is the
		 * installation's.
		 */
		const owner = reportedOwner(failure, laws.schemas)
		if (failure.sqlstate === sqlstates.checkViolation && owner?.kind === "domain") {
			const roster = laws.rosterDomainOf(owner.name)
			if (roster !== undefined) {
				return { kind: "defect", domain: owner.name, roster }
			}
		}
		if (failure.sqlstate === sqlstates.notNullViolation) {
			return generatedViolation(laws, owner, failure.column, written)
		}
		const constraint = failure.constraint
		if (constraint === undefined) {
			return undefined
		}
		if (failure.schema !== undefined && !laws.schemas.has(failure.schema)) {
			return undefined
		}
		if (failure.sqlstate === sqlstates.integrityConstraintViolation) {
			const law = laws.raised.get(constraint)
			const detail = failure.detail
			if (law === undefined || detail === undefined) {
				return undefined
			}
			/** A write statement's refusal, by its DETAIL's tag: no other DETAIL is grizzle's. */
			const refusal = readLawDetail(detail)
			return refusal.kind === "law" ? refusalRejection(law, refusal, decoder) : undefined
		}
		if (owner === undefined) {
			return undefined
		}
		const native = laws.lawsOf(constraint, owner)
		if (native === undefined) {
			return undefined
		}
		const by = nativeObject(constraint, owner)
		switch (native.kind) {
			case "aboveCheck":
				return aboveRejection(aboveRefused(native.law, by), written.above(native.table))
			case "above":
				return aboveRejection(aboveRefused(native.law, by), ownUnjudged)
			case "object":
			case "domain": {
				const tables = new Set(Arr.map(written.relations, (relation) => laws.tableOf(relation)))
				const broken = nativeLaws(native, tables, by)
				const judged = written.judge(
					owner.kind === "table"
						? { kind: "constraint", owner: owner.name, name: constraint }
						: {
								kind: "domain",
								domain: owner.name,
								name: constraint,
								uses: coercedUses(native, tables)
							}
				)
				return {
					kind: "rejected",
					refused: refusedBy(judged.laws, broken),
					witness: judged.witness
				}
			}
		}
	}
