import { Array as Arr, Effect, Stream } from "effect"
import type { CompiledChange } from "#adapter/apply/compile.ts"
import type { HostCall } from "#adapter/apply/run.ts"
import {
	type ChangeSetInput,
	type GroupData,
	type MemberFacts,
	memberSlots
} from "#compiler/plan/change.ts"
import type { ParamMap } from "#compiler/plan/common.ts"

/**
 * Each member slot the compiled ChangeSet reads with the ChangeSet value's input for it, in slot order. The program was
 * compiled from the value's own Description, so the value holds an input for every slot; the engine's normalization
 * reads each slot's facts through its own one site of that fact (write/normalize), so a slot is paired here only with
 * the input the value holds.
 */
const slotInputs = (
	groups: ReadonlyArray<GroupData>,
	inputs: ReadonlyMap<string, ChangeSetInput>
): ReadonlyArray<readonly [string, ChangeSetInput]> =>
	Arr.flatMap(memberSlots(groups), (member) => {
		const input = inputs.get(member)
		return input === undefined ? [] : [[member, input] as const]
	})

/** The facts of every member slot the compiled ChangeSet reads, from the ChangeSet value's inputs. The program was
 * compiled from the value's own Description, so the value holds an input for every slot.
 * A Stream member travels as its arrays like an array: it is collected on the host, whole, before any SQL, since host
 * normalization reads every fact before the transaction begins. A Stream member has no error or requirement channel:
 * the caller handled its failures and provided its services before it became a member, so a caller's retry after a
 * TransientFailure replays it here. The engine receives arrays only. */
export const collectInputs = (
	groups: ReadonlyArray<GroupData>,
	inputs: ReadonlyMap<string, ChangeSetInput>
): Effect.Effect<MemberFacts> =>
	Effect.map(
		Effect.forEach(slotInputs(groups, inputs), ([member, input]) =>
			input.kind === "array"
				? Effect.succeed([member, input.facts] as const)
				: Effect.map(Stream.runCollect(input.stream), (facts) => [member, facts] as const)
		),
		(entries): MemberFacts => new Map<string, Iterable<unknown>>(entries)
	)

/** The call of a ChangeSet value compiled in process (run.ts HostCall): the caller's parameters, the value's bound
 * values, and its members' facts, a Stream member's collected whole (`collectInputs`). */
export const changeCall = (compiled: CompiledChange, params: ParamMap): Effect.Effect<HostCall> =>
	Effect.map(
		collectInputs(compiled.program.flight.binding.groups, compiled.change.inputs),
		(members): HostCall => ({ params, bound: compiled.change.values, members })
	)
