import type { Carrier } from "#compiler/ir/scalar.ts"
import { Decimal } from "#compiler/scalar/values/decimal.ts"
import { convertComponent, convertDouble, convertReal } from "#compiler/scalar/values/float.ts"
import type { CarrierHost, SpecOf } from "#compiler/scalar/values/identity.ts"
import { Money } from "#compiler/scalar/values/money.ts"
import type { Span } from "#compiler/scalar/values/span.ts"
import { Vector } from "#compiler/scalar/values/vector.ts"

/** The conversion of one carrier's output text, built from its spec. */
export type Converter<C extends Carrier> = (text: string) => CarrierHost[C]

/**
 * range_out of a bounded half-open range, "[start,end)", its endpoints read by `endpoint`: the range carrier's own
 * integers, or a span descriptor's endpoint column (scalar/span.ts), whose contract brands them.
 */
export const convertSpan =
	<E>(endpoint: (text: string) => E) =>
	(text: string): Span<E> => {
		const comma = text.indexOf(",")
		return Object.freeze({
			start: endpoint(text.slice(1, comma)),
			end: endpoint(text.slice(comma + 1, -1))
		})
	}

/**
 * vector_out text, "[c1,...,cn]": the components converted straight into a Float32Array of the column's dimensions, one
 * comma at a time, with no intermediate array or substring. The vector is of the column's N dimensions, the tag a
 * pg.vector(N) descriptor's column carries (scalar/vector.ts).
 */
export const convertVector =
	<N extends number>(dimensions: N) =>
	(text: string): Vector<N> => {
		const buffer = new Float32Array(dimensions)
		const last = text.length - 1
		let start = 1
		for (let i = 0; i < dimensions; i++) {
			const comma = text.indexOf(",", start)
			const end = comma < 0 ? last : comma
			buffer[i] = convertComponent(text, start, end)
			start = end + 1
		}
		return Vector.branded(buffer)
	}

const identity = (text: string): string => text

/**
 * The conversion of PostgreSQL's output text of a column into its host value, one per carrier.
 *
 * A conversion trusts its text. Every text it meets is PostgreSQL's own output of a value of the column's type in the
 * fixed execution context Db.open verifies (extra_float_digits = 1, the C.UTF-8 monetary context), written by grizzle's
 * own SQL, whose outermost SELECT casts every column to text: so a conversion checks no syntax, range, typmod, roster or
 * dimension, returns no Result and never refuses. Each one is a straight-line closure built once per descriptor.
 *
 * | Carrier | Text | Host value |
 * | --- | --- | --- |
 * | int2, int4 | int2out, int4out | Number |
 * | int8 | int8out | BigInt |
 * | numeric | numeric_out, display scale kept | Decimal.fromOutput, the text kept as the value's text |
 * | float8 | float8out | Number, -0 as +0 |
 * | float4 | float4out, shortest binary32 text | the binary32 value exactly (float.ts convertReal), -0 as +0 |
 * | money | money::numeric | Money.fromOutput, the minor-unit count |
 * | bool | `true`/`false` (bool::text), `t`/`f` (boolout) | the first letter is t |
 * | uuid, text, enum | uuid_out, the string, the handle | the text itself |
 * | range4, range8 | range_out of a bounded half-open range, [start,end) | a frozen { start, end } |
 * | vector | vector_out, [c1,...,cn] | a Float32Array of the column's dimensions, components exactly binary32 |
 *
 * Every converter is a per-row hot path, run on each value of each row a statement returns: native string methods and
 * index loops, no Option or closure per character, and one allocation for the value itself.
 */
export const convertByCarrier: { readonly [C in Carrier]: (spec: SpecOf<C>) => Converter<C> } = {
	int2: () => Number,
	int4: () => Number,
	int8: () => BigInt,
	numeric: () => (text) => Decimal.fromOutput(text),
	float4: () => convertReal,
	float8: () => convertDouble,
	money: () => (text) => Money.fromOutput(text),
	/** bool::text writes true and false, boolout t and f: one letter tells them apart. */
	bool: () => (text) => text.startsWith("t"),
	uuid: () => identity,
	text: () => identity,
	enum: () => identity,
	range4: () => convertSpan(Number),
	range8: () => convertSpan(BigInt),
	vector: (spec) => convertVector(spec.dimensions)
}
