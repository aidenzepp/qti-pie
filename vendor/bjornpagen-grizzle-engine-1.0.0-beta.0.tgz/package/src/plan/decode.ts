/**
 * What the shell's decode sites read PostgreSQL's output texts by: each column type's reader (codec/read.ts). The
 * architecture's zones give this facade to the shell's readers alone, so no other module of the shell reaches a reader.
 */
export { type ScalarReader, scalarReader } from "#compiler/codec/read.ts"
