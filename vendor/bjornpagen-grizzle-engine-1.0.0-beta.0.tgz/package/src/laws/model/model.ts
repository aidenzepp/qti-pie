import { type CheckedSchema, checkedSchema } from "#compiler/analysis/schema.ts"
import { ViolationBuilder } from "#compiler/analysis/theory/build.ts"
import { lawDescription } from "#compiler/analysis/theory/description.ts"
import type { ResolvedConjunct, TheoryLaw } from "#compiler/analysis/theory/laws.ts"
import {
	buildTheory,
	type PrimaryKeyLaw,
	provisionalTheory,
	type Theory,
	typingEnv
} from "#compiler/analysis/theory/theory.ts"
import { sameMembers, sameOrder } from "#compiler/core/array.ts"
import { catchRefusal, encode, everyProperty, Refusal } from "#compiler/core/canonical.ts"
import { CompileError, malformedDescription, prose } from "#compiler/core/errors.ts"
import {
	type Identity,
	identifierOf,
	identity,
	type KeyColumnName,
	type KeySide
} from "#compiler/core/identity.ts"
import {
	type ColumnIdent,
	type ConstraintName,
	type DomainName,
	type IdentityKind,
	type LawId,
	makeIdSupply,
	type NodeId,
	type RelationIdent
} from "#compiler/core/ids.ts"
import { defect } from "#compiler/core/invariant.ts"
import { heapTupleMaxBytes } from "#compiler/core/limits.ts"
import { SourceLoc } from "#compiler/core/loc.ts"
import { isNonEmpty, mapNonEmpty, type NonEmptyReadonlyArray } from "#compiler/core/nonempty.ts"
import * as Result from "#compiler/core/result.ts"
import { DagBuilder } from "#compiler/ir/builder.ts"
import { mergeDags } from "#compiler/ir/dag.ts"
import { descText, type ExprDesc } from "#compiler/ir/desc.ts"
import { type ExprSpec, identityValueOf, type ScalarExpr } from "#compiler/ir/expr.ts"
import type { Family } from "#compiler/ir/family.ts"
import {
	type DomainCheck,
	type DomainCheckTerm,
	type DomainNative,
	fieldNames,
	type LawColumnValue,
	type LawField,
	type LawLowering,
	type LawRelation,
	type NativeColumn,
	type NativeObject,
	type NativeOf,
	plainFields,
	type RelationInfo,
	type RowGuard,
	type SpanKeyScalars,
	type TheoryRelation
} from "#compiler/ir/law.ts"
import type { ConstraintLaws } from "#compiler/ir/products.ts"
import type { RelNode } from "#compiler/ir/rel.ts"
import { type ContractInfo, contractOf, type ScalarType, textOf } from "#compiler/ir/scalar.ts"

import {
	type CheckPredicate,
	type LawColumnPlan,
	type LawPlan,
	type NativePlan,
	type PlannedColumn,
	type PlannedSpanKey,
	type PrimaryKeyPlan,
	primaryKeyPlan,
	Recognizer
} from "#compiler/laws/model/plan.ts"
import { rowColumn, wideRow } from "#compiler/laws/model/rows.ts"
import { type RelationLaws, relationLaws } from "#compiler/laws/model/uniques.ts"
import {
	type ClosedRelations,
	type LeafDesc,
	lowerPredicate,
	lowerTerm,
	noParams
} from "#compiler/scalar/compute/lower.ts"
import { guardedTerm } from "#compiler/scalar/natural.ts"
import type { Owned } from "#compiler/schema/own.ts"
import type { Law } from "#compiler/types/changeset/changeset.ts"

/** The native objects installed as a table constraint: keys, CHECKs and references. */
export type ConstraintNativeKind =
	| "PrimaryKey"
	| "Unique"
	| "WithoutOverlaps"
	| "TableCheck"
	| "ClosedCheck"
	| "ForeignKey"
	| "PeriodForeignKey"

/** A native object with the identity its installed name was minted from, its namespace, and its owner: the table
 * identifier. Each namespace holds exactly its kinds of object: a table constraint, a law column, a contract's domain,
 * which the installation names by its definition, or an object the law model names nothing for. A table constraint
 * carries the description of the law its violation reports. */
export type NamedNative =
	| {
			readonly object: NativeOf<ConstraintNativeKind>
			readonly namespace: "constraint"
			readonly named: Identity<"primaryKey" | "key" | "check" | "generatedCheck" | "foreignKey">
			readonly owner: RelationIdent
			readonly described: Law
	  }
	| {
			readonly object: NativeOf<"LawColumn">
			readonly namespace: "column"
			readonly named: Identity<"lawColumn">
			readonly owner: RelationIdent
	  }
	| { readonly object: DomainNative; readonly namespace: "domain" }
	| { readonly object: NativeOf<"RosterDomain" | "ReverseIndex">; readonly namespace: "unnamed" }

/** A primary key's native object: a PRIMARY KEY, or a primary key WITHOUT OVERLAPS. */
export type PrimaryNative =
	| NativeOf<"PrimaryKey">
	| (NativeOf<"WithoutOverlaps"> & {
			readonly key: Extract<SpanKeyScalars, { readonly kind: "primary" }>
	  })

/** A relation's primary key as installed: its native object, named by the identity ownership named it by, and the
 * description of the law its violation reports. */
export interface NamedPrimaryKey {
	readonly object: PrimaryNative
	readonly namespace: "constraint"
	readonly named: Identity<"primaryKey" | "key">
	readonly owner: RelationIdent
	readonly described: Law
}

/** An ordinary relation with its primary key as installed. */
export interface KeyedRelation {
	readonly relation: RelationInfo
	readonly primaryKey: NamedPrimaryKey
}

/** A native object as the model's dedup holds it, with every law it discharges and the law that first planned it: an
 * ordinary relation's primary key, seeded before every plan, or any other object. */
type Merged =
	| {
			readonly kind: "primary"
			readonly relation: RelationInfo
			readonly object: PrimaryNative
			readonly laws: [LawId, ...Array<LawId>]
			readonly law: TheoryLaw
	  }
	| {
			readonly kind: "native"
			readonly object: NativeObject
			readonly laws: [LawId, ...Array<LawId>]
			readonly law: TheoryLaw
	  }

/** A primary key's planned object as the model holds it, discharging `lawIds`, each column a field. */
const primaryNative = (
	plan: PrimaryKeyPlan,
	lawIds: NonEmptyReadonlyArray<LawId>
): PrimaryNative => {
	if (plan.kind === "PrimaryKey") {
		return { ...plan, lawIds }
	}
	const field = (c: PlannedColumn): NativeColumn =>
		c.kind === "field" ? c : missing("a primary key's columns, each a field")
	return {
		kind: "WithoutOverlaps",
		relation: plan.relation,
		span: field(plan.span),
		key: { kind: "primary", scalars: mapNonEmpty(plan.key.scalars, field) },
		named: plan.named,
		lawIds
	}
}

/** What the model always holds where it reads it: its absence is a defect. */
const missing = (what: string): never => {
	throw defect(what)
}

/** A primary key named by the identity ownership named it by. */
const namedPrimaryKey = (object: PrimaryNative, described: Law): NamedPrimaryKey => ({
	object,
	named: object.named,
	namespace: "constraint",
	owner: object.relation.ident,
	described
})

/** A law a constraint discharges, with the description its violation reports. */
export interface ConstraintLawOf {
	readonly law: LawId
	readonly described: Law
}

/** One column a contract domain types, with the law of that use: the contract whose domain it is. */
export interface DomainUse {
	readonly table: RelationIdent
	readonly column: ColumnIdent
	readonly law: LawId
}

/**
 * One entry of the constraint-to-LawId map: the identifier a violation reports (a table constraint or a domain
 * constraint), the table or domain that owns it, and every law it discharges with its description, in its native's
 * order (`NativeObject.lawIds`): the first is the one it reports when nothing narrows it, a key law's where a key plans
 * the object, and a merged family axis lists its former's law and every containment that rides it. A domain constraint
 * also lists each column its domain types with that use's law, since PostgreSQL's report of a domain violation names
 * no table or column. The law model emits table constraints only; the installation, which names each contract's domain
 * by its definition, emits the domain constraints.
 */
export type ConstraintLaw =
	| {
			readonly kind: "constraint"
			readonly name: ConstraintName
			readonly owner: RelationIdent
			readonly laws: NonEmptyReadonlyArray<ConstraintLawOf>
	  }
	| {
			readonly kind: "domainConstraint"
			readonly name: ConstraintName
			readonly owner: DomainName
			readonly laws: NonEmptyReadonlyArray<ConstraintLawOf>
			readonly uses: ReadonlyArray<DomainUse>
	  }

/** One kind of owner's constraint names to laws, frozen as the map holds them. */
const frozenOwners = (
	byOwner: ReadonlyMap<string, ReadonlyMap<string, LawId>>
): Readonly<Record<string, Readonly<Record<string, LawId>>>> =>
	Object.freeze(
		Object.fromEntries(
			[...byOwner].map(([owner, named]) => [owner, Object.freeze(Object.fromEntries(named))])
		)
	)

/** The constraint map of a list of entries, by owner and name, each to the law it reports when nothing narrows it,
 * its first. A constraint name is scoped to its table or domain, so each owner and name is one entry. */
export const constraintLawMap = (entries: ReadonlyArray<ConstraintLaw>): ConstraintLaws => {
	const tables = new Map<string, Map<string, LawId>>()
	const domains = new Map<string, Map<string, LawId>>()
	for (const c of entries) {
		const byOwner = c.kind === "domainConstraint" ? domains : tables
		const named = byOwner.get(c.owner) ?? new Map<string, LawId>()
		named.set(c.name, c.laws[0].law)
		byOwner.set(c.owner, named)
	}
	return Object.freeze({ tables: frozenOwners(tables), domains: frozenOwners(domains) })
}

export interface LawModel {
	/** The owned schema the model specializes: every installed identifier a law reads (a table, a column, a roster's
	 * domain, a declared key or check) is the one ownership registered there. */
	readonly owned: Owned
	/** The theory with every law's lowering, and its DAG extended. */
	readonly theory: Theory
	/** Every native object of the schema's laws, once each, in law order. */
	readonly natives: ReadonlyArray<NamedNative>
	/**
	 * Every family of the schema, a tree's included, with its axes and folds resolved (analysis/theory Theory.families):
	 * what the write planner draws and fills, the column order places, and the shell's apply reads. Each drawn law column
	 * it names (its ‹n›, a counted index, a tree's ‹ps›, a hidden accumulator) is a LawColumn native of `natives` under
	 * the same identifier.
	 */
	readonly families: ReadonlyArray<Family>
	/** Each table constraint's identifier with every law it discharges. */
	readonly constraints: ReadonlyArray<ConstraintLaw>
	readonly constraintToLaw: ConstraintLaws
	/** Every identity the law model mints beyond ownership's: its laws', its natives' and its law columns'. */
	readonly identities: ReadonlyArray<Identity<IdentityKind>>
	/** The laws whose containment evidence holds at every statement (an immediate foreign key or a CHECK). */
	readonly immediate: ReadonlySet<LawId>
	/**
	 * The laws that read closed relations only, in law order, discharged once by the migration that installs them: each
	 * runs as its theory law's violation query (NormalizedLaw.violation), which reads the closed relations' rows and no
	 * installed constant, and installs nothing.
	 */
	readonly migrationLaws: ReadonlyArray<LawId>
	/** Each ordinary relation by name, with its primary key and the unique objects its natives install (uniques.ts
	 * relationLaws): one per primary key the model seeds, so one per ordinary relation. */
	readonly relations: ReadonlyMap<string, RelationLaws>
	/** The checker's reading of the owned schema, whose relation handles the theory's laws read. */
	readonly checked: CheckedSchema
}

const unwrap = <A>(r: Result.Result<A, CompileError>): A => {
	if (!r.ok) {
		throw new Refusal(r.error)
	}
	return r.value
}

/** A native object as its structural identity reads it, every law it discharges left out: each handle by its name, so
 * two plans of one object are one object. */
const nativeIdentity = (object: NativeObject): unknown => {
	const { lawIds: _ignored, ...rest } = object
	switch (rest.kind) {
		case "PrimaryKey":
			return { ...rest, relation: rest.relation.name, columns: fieldNames(rest.columns) }
		case "Unique":
		case "ReverseIndex":
			return { ...rest, relation: rest.relation.name, columns: columnNames(rest.columns) }
		case "LawColumn":
			return { kind: rest.kind, relation: rest.relation.name, column: rest.column }
		case "PeriodForeignKey":
			return {
				...rest,
				relation: rest.relation.name,
				columns: columnNames(rest.columns),
				span: columnNames([rest.span]),
				target: rest.target.name,
				targetColumns: columnNames(rest.targetColumns),
				targetSpan: columnNames([rest.targetSpan])
			}
		case "WithoutOverlaps":
			return {
				kind: rest.kind,
				relation: rest.relation.name,
				span: columnNames([rest.span]),
				key: { kind: rest.key.kind, scalars: columnNames(rest.key.scalars) }
			}
		case "TableCheck":
			return { ...rest, relation: rest.relation.name }
		case "ClosedCheck":
			return {
				kind: rest.kind,
				relation: rest.relation.name,
				target: rest.target.name,
				side: { key: rest.side.key, payload: rest.side.payload, rows: [...rest.side.rows] },
				pairs: rest.pairs.map((p) => ({ source: columnNames([p.source]), target: p.target.name })),
				guard: rest.guard.map((g) => g.predicate)
			}
		case "ForeignKey":
			return {
				...rest,
				relation: rest.relation.name,
				columns: columnNames(rest.columns),
				target: rest.target.name,
				targetColumns: columnNames(rest.targetColumns)
			}
		case "Domain":
		case "RosterDomain":
			return rest
	}
}

/** The names of a native's columns: a field's name, a law column's identifier. */
const columnNames = (columns: ReadonlyArray<NativeColumn>): ReadonlyArray<string> =>
	columns.map((c) => (c.kind === "field" ? c.field.name : c.column))

const structuralKey = (object: unknown): string => {
	const text = encode(object, everyProperty)
	if (!text.ok) {
		throw new Refusal(text.error)
	}
	return text.value
}

/** A contract's domain CHECK (`DomainCheck`): its base's refined text pattern, when the base is no contract, and
 * its predicate. */
export const domainCheck = (info: ContractInfo): DomainCheck => {
	const regex = contractOf(info.base) === undefined ? textOf(info.base)?.regex : undefined
	const pattern: ReadonlyArray<DomainCheckTerm> =
		regex === undefined || regex === "wildcard" ? [] : [{ kind: "pattern", regex }]
	const predicate: ReadonlyArray<DomainCheckTerm> =
		info.predicate === undefined ? [] : [{ kind: "predicate", predicate: info.predicate }]
	const terms = [...pattern, ...predicate]
	return isNonEmpty(terms) ? { kind: "checked", terms } : { kind: "unchecked" }
}

/** Strongly connected relations of the foreign key graph (iterative Tarjan); an edge whose ends share a component, a
 * self-reference included, lies on a cycle. A relation outside the graph is in no component, so no edge with it as an
 * end lies on one. */
const cycleEdges = (
	edges: ReadonlyArray<readonly [string, string]>
): ((from: string, to: string) => boolean) => {
	const next = new Map<string, Array<string>>()
	for (const [a, b] of edges) {
		next.set(a, [...(next.get(a) ?? []), b])
		if (!next.has(b)) {
			next.set(b, [])
		}
	}
	/** Each visited node's discovery index and low link. */
	const visited = new Map<string, { readonly index: number; low: number }>()
	const component = new Map<string, number>()
	const stack: Array<string> = []
	const onStack = new Set<string>()
	let counter = 0
	let components = 0
	const visit = (node: string) => {
		const link = { index: counter, low: counter }
		visited.set(node, link)
		counter++
		stack.push(node)
		onStack.add(node)
		return link
	}
	/** Pops the component rooted at `node` off the stack. */
	const popComponent = (node: string): void => {
		for (let popped = stack.pop(); popped !== undefined; popped = stack.pop()) {
			onStack.delete(popped)
			component.set(popped, components)
			if (popped === node) {
				break
			}
		}
		components++
	}
	/** Every component reachable from `root`, walked depth first on a work stack of frames, each a node, its next
	 * successor's position and its link. */
	const strongConnect = (root: string): void => {
		const work: Array<{
			readonly node: string
			i: number
			readonly link: { readonly index: number; low: number }
		}> = [{ node: root, i: 0, link: visit(root) }]
		/** A successor's step: one not yet visited is pushed and lowers nothing yet; one on the stack lowers its
		 * predecessor's link to its index; one in a finished component lowers nothing. */
		const stepTo = (w: string): number | undefined => {
			const seen = visited.get(w)
			if (seen === undefined) {
				work.push({ node: w, i: 0, link: visit(w) })
				return undefined
			}
			return onStack.has(w) ? seen.index : undefined
		}
		for (let frame = work.at(-1); frame !== undefined; frame = work.at(-1)) {
			const w = next.get(frame.node)?.[frame.i]
			if (w !== undefined) {
				frame.i++
				const lowered = stepTo(w)
				if (lowered !== undefined) {
					frame.link.low = Math.min(frame.link.low, lowered)
				}
				continue
			}
			work.pop()
			const parent = work.at(-1)
			if (parent !== undefined) {
				parent.link.low = Math.min(parent.link.low, frame.link.low)
			}
			if (frame.link.low === frame.link.index) {
				popComponent(frame.node)
			}
		}
	}
	for (const root of next.keys()) {
		if (!visited.has(root)) {
			strongConnect(root)
		}
	}
	return (from, to) => {
		const own = component.get(from)
		return own !== undefined && own === component.get(to)
	}
}

/** A foreign key the schema-wide deferral rule decides, as the rule asks about it: its relation, its target and the
 * target's fields it references as plain columns. */
interface DeferralQuery {
	readonly relation: TheoryRelation
	readonly target: TheoryRelation
	readonly targetFields: ReadonlyArray<LawField>
}

/** A plan's native object as the specializer materializes it: a generated CHECK with its predicate lowered into the
 * extension DAG (`#lowerCheck`), a law column with its value lowered there (`ColumnLowering`), a ClosedCheck with its
 * guard lowered, every other as its plan states it. */
type PlacedNative =
	| Exclude<NativePlan, { readonly kind: "GeneratedCheck" | "LawColumn" | "ClosedCheck" }>
	| (Omit<NativeOf<"ClosedCheck">, "lawIds" | "pairs"> & {
			readonly pairs: Extract<NativePlan, { readonly kind: "ClosedCheck" }>["pairs"]
	  })
	| {
			readonly kind: "LoweredCheck"
			readonly relation: RelationInfo
			readonly predicate: ScalarExpr
	  }
	| {
			readonly kind: "LoweredColumn"
			readonly column: LawColumnPlan
			readonly value: LawColumnValue
	  }

/** One relation's row as the law columns on it read it: one scan, its leaf reader, and what is lowered over it. */
interface ColumnRow {
	readonly region: RelNode
	readonly leaf: (desc: LeafDesc, at: SourceLoc) => Result.Result<ExprSpec, CompileError>
	/** Each guard conjunct lowered, by its canonical text. */
	readonly guards: Map<string, ScalarExpr>
	/** Each law column's value, by its identity's canonical text. */
	readonly values: Map<string, LawColumnValue>
}

/** A column of a scan region at `type`, read by its name: a field's, or a law column's identifier. */
const regionColumn = (node: NodeId, name: string, type: ScalarType): ExprSpec => ({
	kind: "column",
	column: { node, name },
	args: [],
	type,
	nonNull: "storage"
})

/**
 * The law columns' values lowered into the extension DAG in "check" mode, where no operation raises, over one scan of
 * each relation's row: each guard conjunct once per relation, by its canonical text, so two columns of one guard read
 * one expression and a UNIQUE over them states it once (uniques.ts); each column's value once per relation and
 * identity, reached from a root of its own. A term's column is guarded by its side's selection's conjuncts, then by
 * its term's own guard (scalar/natural.ts guardedTerm: pred(x) above zero); a constant is its literal under no guard; a
 * counted family's ‹p› is pred of its drawn index, read as that column by its identifier; a drawn column is the host's,
 * and lowers nothing.
 */
class ColumnLowering {
	readonly #ext: ViolationBuilder
	readonly #typing: ReturnType<typeof typingEnv>
	/** The closed relations a guard or a term may apply (CheckedSchema.closedReads). */
	readonly #closed: ClosedRelations
	readonly #roots: Array<RelNode>
	/** The identifier of a law column, which a value reading another law column reads it by. */
	readonly #identifier: (plan: LawColumnPlan) => ColumnIdent
	readonly #rows = new Map<string, ColumnRow>()

	constructor(
		ext: ViolationBuilder,
		typing: ReturnType<typeof typingEnv>,
		closed: ClosedRelations,
		roots: Array<RelNode>,
		identifier: (plan: LawColumnPlan) => ColumnIdent
	) {
		this.#ext = ext
		this.#typing = typing
		this.#closed = closed
		this.#roots = roots
		this.#identifier = identifier
	}

	/**
	 * A ClosedCheck's guards: each conjunct of its source's selection lowered over the source's row, once per relation by
	 * its canonical text as a law column's guard is, with the fields it reads, reached from a root of their own.
	 */
	guards(
		relation: TheoryRelation,
		conjuncts: ReadonlyArray<ResolvedConjunct>,
		loc: SourceLoc
	): ReadonlyArray<RowGuard> {
		const row = this.#row(relation)
		const guards = conjuncts.map((c): RowGuard => ({
			predicate: this.#guard(row, c.predicate, c.text, loc),
			reads: c.reads
		}))
		if (isNonEmpty(guards)) {
			this.#roots.push(
				this.#ext.project(
					row.region,
					guards.map((g, i) => [`guard${i}`, g.predicate] as const)
				)
			)
		}
		return guards
	}

	value(plan: LawColumnPlan, named: Identity<"lawColumn">, loc: SourceLoc): LawColumnValue {
		if (plan.kind === "drawn") {
			return { kind: "drawn", draws: plan.draws }
		}
		const row = this.#row(plan.relation)
		const known = row.values.get(named.canonical)
		if (known !== undefined) {
			return known
		}
		const value = this.#lower(row, plan, loc)
		row.values.set(named.canonical, value)
		this.#roots.push(
			this.#ext.project(row.region, [
				...value.guard.map((g, i) => [`guard${i}`, g] as const),
				["term", value.term]
			])
		)
		return value
	}

	#lower(
		row: ColumnRow,
		plan: Exclude<LawColumnPlan, { readonly kind: "drawn" }>,
		loc: SourceLoc
	): Extract<LawColumnValue, { readonly kind: "generated" }> {
		switch (plan.kind) {
			case "constant":
				return {
					kind: "generated",
					guard: [],
					term: this.#ext.typed(plan.value, plan.field.type)
				}
			case "term": {
				const own = guardedTerm(plan.term)
				return {
					kind: "generated",
					guard: [
						...plan.selection.conjuncts.map((c) => this.#guard(row, c.predicate, c.text, loc)),
						...own.guard.map((g) => this.#guard(row, g, unwrap(descText(g)), loc))
					],
					term: unwrap(lowerTerm(own.term, this.#env(row, loc, new Map()))).expr
				}
			}
			case "indexPred": {
				const index = this.#identifier(plan.index)
				const own = guardedTerm({ kind: "pred", field: index })
				const env = this.#env(row, loc, new Map([[index, plan.field.type]]))
				return {
					kind: "generated",
					guard: own.guard.map((g) => unwrap(lowerPredicate(g, env)).expr),
					term: unwrap(lowerTerm(own.term, env)).expr
				}
			}
		}
	}

	#guard(row: ColumnRow, predicate: ExprDesc, text: string, loc: SourceLoc): ScalarExpr {
		const known = row.guards.get(text)
		if (known !== undefined) {
			return known
		}
		const lowered = unwrap(lowerPredicate(predicate, this.#env(row, loc, new Map()))).expr
		row.guards.set(text, lowered)
		return lowered
	}

	/** The lowering environment over `row`, which also reads each law column of `lawColumns` by its identifier at the type
	 * of the values it holds. */
	#env(row: ColumnRow, loc: SourceLoc, lawColumns: ReadonlyMap<string, ScalarType>) {
		return {
			...this.#typing,
			closed: this.#closed,
			mode: "check" as const,
			loc,
			emit: (spec: ExprSpec) => this.#ext.expr(spec),
			params: noParams,
			leaf: (desc: LeafDesc, at: SourceLoc): Result.Result<ExprSpec, CompileError> => {
				const type = desc.kind === "field" ? lawColumns.get(desc.field) : undefined
				return desc.kind === "field" && type !== undefined
					? Result.ok(regionColumn(row.region.id, desc.field, type))
					: row.leaf(desc, at)
			}
		}
	}

	#row(r: TheoryRelation): ColumnRow {
		const known = this.#rows.get(r.name)
		if (known !== undefined) {
			return known
		}
		const region = this.#ext.scan(r, r.fields, [])
		const row: ColumnRow = {
			region,
			leaf: (desc, at) => {
				const field =
					desc.kind === "field" ? r.fields.find((f) => f.name === desc.field) : undefined
				return field === undefined
					? Result.err(
							malformedDescription(at, `a field of ${r.name}, not a ${desc.kind} reference`)
						)
					: Result.ok(columnLeaf(region.id, field))
			},
			guards: new Map(),
			values: new Map()
		}
		this.#rows.set(r.name, row)
		return row
	}
}

class Specializer {
	readonly theory: Theory
	readonly checked: CheckedSchema
	readonly owned: Owned
	readonly recognizer: Recognizer
	/** The typing environment every lowering of the model reads, each text pattern analyzed once in it. */
	readonly #typing: ReturnType<typeof typingEnv>
	readonly #minted: Array<Identity<IdentityKind>> = []
	/** Each law column's identity, which names its native once it is merged, by its relation and identifier. */
	readonly #lawColumns = new Map<string, Map<ColumnIdent, Identity<"lawColumn">>>()
	/** Every law by its id, a primary key's included: what a constraint's every law is described by. */
	readonly #laws: ReadonlyMap<LawId, TheoryLaw>

	constructor(theory: Theory, checked: CheckedSchema) {
		this.theory = theory
		this.checked = checked
		this.owned = checked.owned
		this.recognizer = new Recognizer(theory.laws, theory.families, theory.relations)
		this.#typing = typingEnv(checked.owned)
		this.#laws = new Map([
			...theory.laws.map((l) => [l.id, l] as const),
			...theory.primaryKeys.map((pk) => [pk.law.id, pk.law] as const)
		])
	}

	/** The identifier of a law column, its identity kept to name its native. */
	#lawColumn(plan: LawColumnPlan): ColumnIdent {
		const named = lawColumnIdentity(plan)
		const own =
			this.#lawColumns.get(plan.relation.name) ?? new Map<ColumnIdent, Identity<"lawColumn">>()
		const column = identifierOf(named)
		if (!own.has(column)) {
			this.#named(named)
			own.set(column, named)
			this.#lawColumns.set(plan.relation.name, own)
		}
		return column
	}

	/** The identity of the law column `column` of `relation`, which every law column the model names was minted with. */
	#lawColumnNamed(relation: LawRelation, column: ColumnIdent): Identity<"lawColumn"> {
		const named = this.#lawColumns.get(relation.name)?.get(column)
		if (named === undefined) {
			throw defect(`the law column ${column} of ${relation.name}, minted as it is planned`)
		}
		return named
	}

	/** A planned column as its native reads it: a field, or a law column by its identifier. */
	#column(c: PlannedColumn): NativeColumn {
		switch (c.kind) {
			case "field":
				return c
			case "law":
				return { kind: "law", column: this.#lawColumn(c.column) }
		}
	}

	/** A native's columns as its name reads them: a field by its name, a law column by its identity. */
	#keyNames(
		relation: LawRelation,
		columns: ReadonlyArray<NativeColumn>
	): ReadonlyArray<KeyColumnName> {
		return columns.map((c): KeyColumnName =>
			c.kind === "field" ? c.field.name : this.#lawColumnNamed(relation, c.column)
		)
	}

	/** An identity the law model mints, kept for the installation's census and comments. */
	#named<K extends IdentityKind>(named: Identity<K>): Identity<K> {
		this.#minted.push(named)
		return named
	}

	run(): LawModel {
		const plans = this.theory.laws.map((law) => this.recognizer.plan(law))
		const deferred = this.#deferral(plans)

		/** The extension DAG: each generated CHECK's predicate and each law column's value. */
		const ext = new ViolationBuilder(SourceLoc(`schema ${this.owned.name}`, []))
		const roots: Array<RelNode> = []
		const columns = new ColumnLowering(ext, this.#typing, this.checked.closedReads, roots, (plan) =>
			this.#lawColumn(plan)
		)
		/** Each plan with its native objects, a generated CHECK's predicate and a law column's value lowered into the
		 * extension DAG. */
		const place = (n: NativePlan, plan: LawPlan): PlacedNative => {
			switch (n.kind) {
				case "GeneratedCheck": {
					const { filter, predicate } = this.#lowerCheck(ext, n.relation, n.check, plan.law.loc)
					roots.push(filter)
					return { kind: "LoweredCheck", relation: n.relation, predicate }
				}
				case "LawColumn":
					return {
						kind: "LoweredColumn",
						column: n.column,
						value: columns.value(n.column, lawColumnIdentity(n.column), plan.law.loc)
					}
				case "ClosedCheck":
					return { ...n, guard: columns.guards(n.relation, n.guard, plan.law.loc) }
				case "PrimaryKey":
				case "Unique":
				case "Domain":
				case "TableCheck":
				case "RosterDomain":
				case "ForeignKey":
				case "WithoutOverlaps":
				case "PeriodForeignKey":
				case "ReverseIndex":
					return n
			}
		}
		const placed = plans.map((plan) => ({
			plan,
			natives: plan.natives.map((n) => place(n, plan))
		}))
		/** A schema with no generated CHECK and no law column adds nothing to the DAG. */
		const merged =
			roots.length === 0
				? { dag: this.theory.dag, expr: (e: ScalarExpr) => e }
				: mergeDags(this.theory.dag, ext.b.build(roots))

		/** Native objects, merged: each first seen with its law list, which every later plan of the same object extends,
		 * so the object holds every law it discharges once all plans are read. Each ordinary relation's primary key is
		 * seen first, with its own law: a primary key merges only with a plan of the same key. */
		const byKey = new Map<string, Merged>()
		for (const pk of this.theory.primaryKeys) {
			this.#seed(byKey, pk)
		}
		const immediate = new Set<LawId>()
		const implyingKey = this.#implyingKey()
		/** Key laws first, so an object a key law and another law both plan reports the key's law. */
		const keysFirst = [
			...placed.filter((p) => isKeyLaw(p.plan.law)),
			...placed.filter((p) => !isKeyLaw(p.plan.law))
		]
		const nativeObjects = keysFirst.map(({ plan, natives: placedNatives }) => {
			const objects: Array<NativeObject> = []
			for (const n of placedNatives) {
				const object = this.#materialize(n, plan, deferred, (e) => merged.expr(e))
				if (
					(object.kind === "ForeignKey" && !object.deferrable) ||
					object.kind === "ClosedCheck" ||
					(object.kind === "TableCheck" && plan.law.detail.kind === "containment")
				) {
					immediate.add(plan.law.id)
				}
				const key = structuralKey(nativeIdentity(object))
				const known = byKey.get(key)
				if (known === undefined) {
					const laws = this.#firstLaws(n, plan, implyingKey)
					const seen: NativeObject = { ...object, lawIds: laws }
					byKey.set(key, {
						kind: "native",
						object: seen,
						laws,
						law: this.#lawOf(laws[0])
					})
					objects.push(seen)
					continue
				}
				if (!known.laws.includes(plan.law.id)) {
					known.laws.push(plan.law.id)
				}
				objects.push(known.object)
			}
			return { plan, objects }
		})

		/** Names and the constraint map, each object once, in the order it was first seen; each primary key with its
		 * relation. */
		const natives: Array<NamedNative> = []
		const keyed: Array<KeyedRelation> = []
		const constraints: Array<ConstraintLaw> = []
		for (const entry of byKey.values()) {
			const described = lawDescription(entry.law)
			const named = this.#nameMerged(entry, described, keyed)
			natives.push(named)
			if (named.namespace === "constraint") {
				constraints.push({
					kind: "constraint",
					name: identifierOf(named.named),
					owner: named.owner,
					laws: mapNonEmpty(entry.laws, (law) => ({
						law,
						described: lawDescription(this.#lawOf(law))
					}))
				})
			}
		}

		this.#refuseWideRows(natives)
		const lowered: Record<LawId, LawLowering> = {}
		for (const { plan, objects } of nativeObjects) {
			lowered[plan.law.id] = Object.freeze({ natives: [...new Set(objects)] })
		}
		return {
			owned: this.owned,
			theory: Object.freeze({ ...this.theory, dag: merged.dag, lowerings: Object.freeze(lowered) }),
			natives,
			families: this.theory.families,
			constraints,
			constraintToLaw: constraintLawMap(constraints),
			identities: [...this.theory.laws.map((law) => law.named), ...this.#minted],
			immediate,
			migrationLaws: plans.flatMap((plan) => (plan.discharge === "migration" ? [plan.law.id] : [])),
			relations: relationLaws(keyed, natives),
			checked: this.checked
		}
	}

	/**
	 * Refuses a relation whose rows can exceed one heap tuple (MaxHeapTupleSize, `heapTupleMaxBytes`): its fields and
	 * every law column on it, a generated one outside its guard NULL, each counted at the most it can take inline once
	 * every variable-length value that can be is moved out of line (rows.ts).
	 */
	#refuseWideRows(natives: ReadonlyArray<NamedNative>): void {
		const lawColumns = new Map<string, Array<NativeOf<"LawColumn">>>()
		for (const n of natives) {
			if (n.namespace !== "column") {
				continue
			}
			const own = lawColumns.get(n.object.relation.name) ?? []
			own.push(n.object)
			lawColumns.set(n.object.relation.name, own)
		}
		for (const r of Object.values(this.theory.relations)) {
			if (r.kind !== "relation") {
				continue
			}
			const columns = [
				...r.fields.map((f) => rowColumn(f.desc, false)),
				...(lawColumns.get(r.name) ?? []).map((c) =>
					rowColumn(c.field.desc, c.value.kind === "generated" && c.value.guard.length > 0)
				)
			]
			const refused = wideRow(r.name, columns, heapTupleMaxBytes.value)
			if (refused !== undefined) {
				throw new Refusal(CompileError.make(prose("UnsupportedLawFamily", r.loc, refused)))
			}
		}
	}

	/** The law `id` names, which the theory states. */
	#lawOf(id: LawId): TheoryLaw {
		return this.#laws.get(id) ?? missing(`the law ${id}, which the theory states`)
	}

	/**
	 * The laws a native object first seen in `plan` discharges, the reported one first: a family axis's every law its
	 * plan names, its former's first; a generated UNIQUE whose fields hold a declared key, that key's law and then its
	 * own; any other, its plan's law.
	 */
	#firstLaws(
		n: PlacedNative,
		plan: LawPlan,
		implyingKey: (
			unique: Extract<PlacedNative, { readonly kind: "Unique" }>
		) => TheoryLaw | undefined
	): [LawId, ...Array<LawId>] {
		if (n.kind === "ForeignKey" && n.laws !== undefined) {
			const [first, ...rest] = n.laws
			return [
				first,
				...rest.filter((l) => l !== first),
				...(n.laws.includes(plan.law.id) ? [] : [plan.law.id])
			]
		}
		const implying = n.kind === "Unique" ? implyingKey(n) : undefined
		return implying === undefined || implying.id === plan.law.id
			? [plan.law.id]
			: [implying.id, plan.law.id]
	}

	/**
	 * The declared key a generated UNIQUE's conflicts imply, by its relation's keys in key order, the primary key first:
	 * one whose fields its compared fields contain, a law column comparing the field whose values it holds. Every two
	 * rows the UNIQUE holds apart agree at that key's fields, so a state it refuses breaks the key too, whatever index
	 * PostgreSQL checks first: the UNIQUE discharges the key's law beside its own and reports the key's, the law the
	 * state breaks (a superkey a reference's target needs, or a selected target's law columns over a key). Undefined
	 * when its fields contain no declared key.
	 */
	#implyingKey(): (
		unique: Extract<PlacedNative, { readonly kind: "Unique" }>
	) => TheoryLaw | undefined {
		const keys = new Map<
			string,
			Array<{ readonly fields: ReadonlyArray<LawField>; readonly law: TheoryLaw }>
		>()
		const add = (relation: string, fields: ReadonlyArray<LawField>, law: TheoryLaw): void => {
			keys.set(relation, [...(keys.get(relation) ?? []), { fields, law }])
		}
		for (const pk of this.theory.primaryKeys) {
			add(pk.relation.name, pk.relation.primaryFields, pk.law)
		}
		for (const law of this.theory.laws) {
			if (law.detail.kind === "key" && !law.detail.key.primary) {
				add(law.detail.relation, law.detail.key.fields, law)
			}
		}
		return (unique) => {
			const compared = unique.columns.flatMap((c): ReadonlyArray<LawField> => {
				if (c.kind === "field") {
					return [c.field]
				}
				const column = c.column
				return column.kind === "term" ? [column.term.column] : []
			})
			return keys
				.get(unique.relation.name)
				?.find((k) => k.fields.every((f) => compared.includes(f)))?.law
		}
	}

	/** Seeds `byKey` with the primary key of `pk`'s relation, planned from its key and discharging its law. */
	#seed(byKey: Map<string, Merged>, pk: PrimaryKeyLaw): void {
		const laws: [LawId, ...Array<LawId>] = [pk.law.id]
		const object = primaryNative(
			primaryKeyPlan(pk.relation, pk.relation.keyNames[0], pk.law.loc),
			laws
		)
		byKey.set(structuralKey(nativeIdentity(object)), {
			kind: "primary",
			relation: pk.relation,
			object,
			laws,
			law: pk.law
		})
	}

	/** The installed identifier of a merged object (`#name`), a primary key's kept with its relation in `keyed`. */
	#nameMerged(entry: Merged, described: Law, keyed: Array<KeyedRelation>): NamedNative {
		if (entry.kind === "native") {
			return this.#name(entry.object, entry.law.named, described)
		}
		const primaryKey = namedPrimaryKey(entry.object, described)
		keyed.push({ relation: entry.relation, primaryKey })
		return primaryKey
	}

	/**
	 * Which foreign keys the schema-wide rule defers (see `compileLaws`): those on a cycle of the rule's own foreign keys
	 * and PERIOD foreign keys, or into a replaceable target. A family axis fixes its own deferral and is no edge of the
	 * cycle graph: a family's members are written only through its planner, which orders them.
	 */
	#deferral(plans: ReadonlyArray<LawPlan>): (fk: DeferralQuery) => boolean {
		const edges = plans.flatMap((plan) =>
			plan.natives.flatMap((n): ReadonlyArray<readonly [string, string]> =>
				(n.kind === "ForeignKey" && n.deferral === "rule") || n.kind === "PeriodForeignKey"
					? [[n.relation.name, n.target.name]]
					: []
			)
		)
		const onCycle = cycleEdges(edges)
		return (fk) =>
			onCycle(fk.relation.name, fk.target.name) ||
			fk.target.fields.some((c) => !fk.targetFields.includes(c))
	}

	/**
	 * A generated CHECK predicate lowered in "check" mode over a scan of its table, each of its leaves read as its plan
	 * names it: a field, a law column by its identifier at the type of the values it holds, or a literal at its type.
	 * Each field is read at its own type, so a literal bound adopts the field's contract as in a declared row check;
	 * when that adoption refuses (two contracts compared, or arithmetic over a contract), the predicate is lowered over
	 * the base types of every contract-typed leaf instead, which is the same predicate on every stored value.
	 */
	#lowerCheck(
		ext: ViolationBuilder,
		r: RelationInfo,
		check: CheckPredicate,
		loc: SourceLoc
	): { readonly filter: RelNode; readonly predicate: ScalarExpr } {
		const typeOf = (name: string): ScalarType | undefined => {
			const leaf = check.leaves.get(name)
			return leaf === undefined ? r.fields.find((f) => f.name === name)?.type : leaf.type
		}
		const attempt = (desc: ExprDesc, emit: (spec: ExprSpec) => ScalarExpr, node: NodeId) =>
			lowerPredicate(desc, {
				...this.#typing,
				closed: this.checked.closedReads,
				mode: "check",
				loc,
				emit,
				params: noParams,
				leaf: (leaf: LeafDesc): Result.Result<ExprSpec, CompileError> => {
					if (leaf.kind !== "field") {
						return Result.err(
							malformedDescription(loc, `a field of ${r.name}, not a ${leaf.kind} reference`)
						)
					}
					const named = check.leaves.get(leaf.field)
					if (named === undefined) {
						const field = r.fields.find((f) => f.name === leaf.field)
						return field === undefined
							? Result.err(malformedDescription(loc, `a field of ${r.name}, not ${leaf.field}`))
							: Result.ok(columnLeaf(node, field))
					}
					switch (named.kind) {
						case "law":
							return Result.ok(regionColumn(node, this.#lawColumn(named.column), named.type))
						case "literal":
							return Result.ok({
								kind: "literal",
								value: named.literal,
								args: [],
								type: named.type,
								nonNull: "literal"
							})
					}
				}
			})
		const trial = new DagBuilder(makeIdSupply())
		const placeholder = trial.reserve()
		const plain = attempt(check.predicate, (spec) => trial.expr(spec), placeholder)
		const desc = plain.ok ? check.predicate : baseLeaves(check.predicate, typeOf)
		const region = ext.scan(r, r.fields, [])
		const lowered = unwrap(attempt(desc, (spec) => ext.expr(spec), region.id)).expr
		return { filter: ext.filter(region, lowered), predicate: lowered }
	}

	#materialize(
		n: PlacedNative,
		plan: LawPlan,
		deferred: (fk: DeferralQuery) => boolean,
		renamed: (e: ScalarExpr) => ScalarExpr
	): NativeObject {
		const lawIds: NonEmptyReadonlyArray<LawId> = [plan.law.id]
		switch (n.kind) {
			case "PrimaryKey":
			case "RosterDomain":
				return { ...n, lawIds }
			case "WithoutOverlaps": {
				const span = this.#column(n.span)
				const key = this.#spanKey(n.key)
				const columns = [...key.scalars, span]
				return {
					kind: "WithoutOverlaps",
					relation: n.relation,
					span,
					key,
					named:
						n.named ??
						this.#named(identity.key(n.relation.name, this.#keyNames(n.relation, columns))),
					lawIds
				}
			}
			case "ClosedCheck":
				return {
					kind: "ClosedCheck",
					relation: n.relation,
					target: n.target,
					side: n.side,
					pairs: mapNonEmpty(n.pairs, (p) => ({
						source: this.#column(p.source),
						target: p.target
					})),
					guard: n.guard.map((g) => ({ predicate: renamed(g.predicate), reads: g.reads })),
					lawIds
				}
			case "ReverseIndex":
				return {
					kind: "ReverseIndex",
					relation: n.relation,
					columns: mapNonEmpty(n.columns, (c) => this.#column(c)),
					lawIds
				}
			case "Unique": {
				/** A generated unique over the column set of a declared scalar key is that key; a span key is WITHOUT
				 * OVERLAPS, not a B-tree uniqueness, so its exact-repeat arbiter stays its own object. */
				const target = n.relation
				const fields = n.columns.every((c) => c.kind === "field")
					? plainFields(n.columns.map((c) => this.#column(c)))
					: undefined
				const declared =
					fields === undefined
						? undefined
						: target.keyNames.find(
								(k) => k.span === undefined && sameMembers<LawField>(k.fields, fields)
							)
				if (declared === undefined) {
					return {
						kind: "Unique",
						relation: target,
						columns: mapNonEmpty(n.columns, (c) => this.#column(c)),
						lawIds
					}
				}
				const columns = declared.fields
				return declared.primary
					? {
							kind: "PrimaryKey",
							relation: target,
							columns,
							named: declared.named,
							lawIds
						}
					: {
							kind: "Unique",
							relation: target,
							columns: mapNonEmpty(columns, (field): NativeColumn => ({ kind: "field", field })),
							lawIds
						}
			}
			case "Domain": {
				const info = unwrap(this.#typing.contractInfo(n.contract.desc, n.contract.loc))
				return {
					kind: "Domain",
					name: n.contract.name,
					base: info.base,
					check: domainCheck(info),
					lawIds
				}
			}
			case "TableCheck":
				return {
					kind: "TableCheck",
					relation: n.relation,
					check: { kind: "declared", name: n.name, named: n.named },
					predicate: n.predicate,
					lawIds
				}
			case "LoweredCheck":
				return {
					kind: "TableCheck",
					relation: n.relation,
					check: { kind: "generated", law: plan.law.id },
					predicate: renamed(n.predicate),
					lawIds
				}
			case "LoweredColumn": {
				const c = n.column
				return {
					kind: "LawColumn",
					relation: c.relation,
					column: this.#lawColumn(c),
					field: heldField(c),
					value:
						n.value.kind === "drawn"
							? n.value
							: {
									kind: "generated",
									guard: n.value.guard.map(renamed),
									term: renamed(n.value.term)
								},
					lawIds
				}
			}
			case "ForeignKey":
				return {
					kind: "ForeignKey",
					relation: n.relation,
					columns: mapNonEmpty(n.columns, (c) => this.#column(c)),
					target: n.target,
					targetColumns: mapNonEmpty(n.targetColumns, (c) => this.#column(c)),
					deferrable:
						n.deferral === "rule"
							? deferred({
									relation: n.relation,
									target: n.target,
									targetFields: n.targetColumns.flatMap((c) =>
										c.kind === "field" ? [c.field] : []
									)
								})
							: n.deferral === "deferred",
					onUpdate: n.onUpdate,
					lawIds
				}
			case "PeriodForeignKey":
				return {
					kind: "PeriodForeignKey",
					relation: n.relation,
					columns: n.columns.map((c) => this.#column(c)),
					span: this.#column(n.span),
					target: n.target,
					targetColumns: n.targetColumns.map((c) => this.#column(c)),
					targetSpan: this.#column(n.targetSpan),
					deferrable: deferred({
						relation: n.relation,
						target: n.target,
						targetFields: n.targetColumns.flatMap((c) => (c.kind === "field" ? [c.field] : []))
					}),
					lawIds
				}
		}
	}

	/** A planned span key's scalar columns as the native reads them. */
	#spanKey(key: PlannedSpanKey): SpanKeyScalars {
		switch (key.kind) {
			case "primary":
				return { kind: "primary", scalars: mapNonEmpty(key.scalars, (c) => this.#column(c)) }
			case "unique":
				return { kind: "unique", scalars: key.scalars.map((c) => this.#column(c)) }
		}
	}

	/** The installed identifier of one native object, minted at the naming door (see `compileLaws`). `reported` is the
	 * identity of the law it reports, its first: the law of the plan that first built it, `described`. */
	#name(object: NativeObject, reported: Identity<"law">, described: Law): NamedNative {
		const ownedKey = (relation: LawRelation, columns: ReadonlyArray<LawField>) =>
			relation.keyNames.find((k) => !k.primary && sameOrder<LawField>(k.fields, columns))
		const constraint = (
			on: NativeOf<ConstraintNativeKind>,
			named: Identity<"primaryKey" | "key" | "check" | "generatedCheck" | "foreignKey">
		): NamedNative => ({
			object: on,
			named,
			namespace: "constraint",
			owner: on.relation.ident,
			described
		})
		const side = (relation: LawRelation, fields: ReadonlyArray<KeyColumnName>): KeySide => ({
			relation: relation.name,
			fields
		})
		const foreignKey = (
			on: NativeOf<"ForeignKey" | "PeriodForeignKey">,
			from: KeySide,
			to: KeySide,
			period: boolean
		): NamedNative => constraint(on, this.#named(identity.foreignKey(from, to, period)))
		switch (object.kind) {
			case "PrimaryKey":
				return constraint(object, object.named)
			case "Unique": {
				const fields = plainFields(object.columns)
				const k = fields === undefined ? undefined : ownedKey(object.relation, fields)
				return constraint(
					object,
					k === undefined
						? this.#named(
								identity.key(object.relation.name, this.#keyNames(object.relation, object.columns))
							)
						: k.named
				)
			}
			case "WithoutOverlaps":
				return constraint(object, object.named)
			case "TableCheck":
				return constraint(
					object,
					object.check.kind === "declared"
						? object.check.named
						: this.#named(identity.generatedCheck(object.relation.name, reported))
				)
			case "ClosedCheck":
				return constraint(
					object,
					this.#named(identity.generatedCheck(object.relation.name, reported))
				)
			case "ForeignKey":
				return foreignKey(
					object,
					side(object.relation, this.#keyNames(object.relation, object.columns)),
					side(object.target, this.#keyNames(object.target, object.targetColumns)),
					false
				)
			case "PeriodForeignKey":
				return foreignKey(
					object,
					side(object.relation, this.#keyNames(object.relation, [...object.columns, object.span])),
					side(
						object.target,
						this.#keyNames(object.target, [...object.targetColumns, object.targetSpan])
					),
					true
				)
			case "LawColumn":
				return {
					object,
					named: this.#lawColumnNamed(object.relation, object.column),
					namespace: "column",
					owner: object.relation.ident
				}
			case "Domain":
				return { object, namespace: "domain" }
			case "RosterDomain":
			case "ReverseIndex":
				return { object, namespace: "unnamed" }
		}
	}
}

/** Whether a law is a key, a declared one or one over a projected side, whose violation an object it plans reports. */
const isKeyLaw = (law: TheoryLaw): boolean =>
	law.detail.kind === "key" || law.detail.kind === "projectedKey"

/** The field whose values a law column holds, its type the column's and an index entry over it sized as one of the
 * field's: a term's own field, a constant's target field, a drawn column's or a counted predecessor's count. */
const heldField = (c: LawColumnPlan): LawField => {
	switch (c.kind) {
		case "constant":
		case "drawn":
		case "indexPred":
			return c.field
		case "term":
			return c.term.column
	}
}

/** A law column's identity at the naming door, by what it is (core/identity.ts LawColumnStatement): a constant by
 * its target, field and value; a term by its kind, its field and its selection's conjuncts' canonical texts; a drawn
 * column as its plan states it, by its family and what it draws, a hidden accumulator by its fold's law; a counted
 * family's ‹p› by its family. */
const lawColumnIdentity = (plan: LawColumnPlan): Identity<"lawColumn"> => {
	switch (plan.kind) {
		case "constant":
			return identity.lawColumn({
				kind: "constant",
				target: plan.target.name,
				field: plan.field.name,
				value: identityValueOf(plan.value)
			})
		case "term":
			return identity.lawColumn({
				kind: "term",
				term: { kind: plan.term.kind, field: plan.term.field },
				selection: plan.selection.conjuncts.map((c) => c.text)
			})
		case "drawn":
			return identity.lawColumn(plan.named)
		case "indexPred":
			return identity.lawColumn({
				kind: "predecessor",
				owner: plan.family.owner,
				count: plan.family.count
			})
	}
}

const columnLeaf = (node: NodeId, field: LawField): ExprSpec => ({
	kind: "column",
	column: { node, name: field.name },
	args: [],
	type: field.type,
	nonNull: "storage"
})

/** The predicate with every field leaf of a contract type read as its base (Compute.base), at any depth. A leaf already
 * under a base stays as it is. */
const baseLeaves = (
	predicate: ExprDesc,
	typeOf: (name: string) => ScalarType | undefined
): ExprDesc => {
	const walk = (d: ExprDesc): ExprDesc => {
		switch (d.kind) {
			case "field": {
				const type = typeOf(d.field)
				return type !== undefined && contractOf(type) !== undefined ? { kind: "base", arg: d } : d
			}
			case "compute":
				return { ...d, args: d.args.map(walk) }
			case "compare":
				return { ...d, left: walk(d.left), right: walk(d.right) }
			case "and":
			case "or":
				return { ...d, args: mapNonEmpty(d.args, walk) }
			case "not":
			case "cast":
			case "in":
				return { ...d, arg: walk(d.arg) }
			case "cond":
				return { ...d, pred: walk(d.pred), onTrue: walk(d.onTrue), onFalse: walk(d.onFalse) }
			case "when":
				return {
					...d,
					subject: walk(d.subject),
					proved: walk(d.proved),
					otherwise: walk(d.otherwise)
				}
			case "between":
				return { ...d, arg: walk(d.arg), low: walk(d.low), high: walk(d.high) }
			case "allen":
				return { ...d, left: walk(d.left), right: walk(d.right) }
			case "pointIn":
				return { ...d, point: walk(d.point), span: walk(d.span) }
			case "closedAt":
				return { ...d, args: mapNonEmpty(d.args, walk) }
			case "closedRow":
				return { ...d, args: d.args.map(walk) }
			case "base":
			case "literal":
			case "param":
			case "absent":
			case "var":
			case "value":
			case "parent":
				return d
		}
	}
	return walk(predicate)
}

const specialize = (
	theory: Theory,
	checked: CheckedSchema
): Result.Result<LawModel, CompileError> =>
	catchRefusal(() => new Specializer(theory, checked).run())

/** Law specialization: an owned schema's CheckedTheory with every law's LawLowering. It runs theory normalization with
 * the law identities the naming door gives (theory.ts lawIdentityOf), recognizes every normalized law (`Recognizer`),
 * and settles what depends on the whole schema at once:
 *
 * - Law columns: each term of a selected side and each pred term is a STORED generated column of its relation, a
 *   constant selection of a target a STORED constant column of its source, and a family's ‹n›, counted index, tree's
 *   ‹ps› and hidden fold accumulators plain columns the host draws, each named once by what it is
 *   (identity.lawColumn) and lowered once over its table's row. The generated UNIQUE a reference needs is over exactly
 *   the target's columns, a constant selection's the target's fields then its selector fields. A generated unique
 *   whose column set is a declared key of the target is that key.
 * - Foreign key deferral: a family axis's is its own (the owner axis immediate unless its ON UPDATE CASCADE feeds its target, a tree's from its plain parent with no action and immediate, an
 *   ordered predecessor immediate, a counted predecessor and every last axis deferred). Any other foreign key, a
 *   PERIOD one included, is deferred exactly when a lawful final-state ChangeSet could break it in passing: when its
 *   target can be replaced at the referenced key, because the target has a field it does not reference as a plain
 *   column, so a put or a deletion and an addition at that key deletes the referenced row before inserting its
 *   replacement; or when it lies on a cycle of those foreign keys, where neither side can be inserted first. A PERIOD
 *   foreign key references its target's span as a period, never as a plain column, so it is always deferred: the
 *   facts covering a referenced span can be replaced by others that still cover it, a span cut or split, and the
 *   target's WITHOUT OVERLAPS key admits the replacements only once the facts they overlap are deleted. Any role
 *   over the schema may write any ordinary relation, and roles are defined beside the schema, never in it, so the
 *   schema's own laws are the same whoever writes. Otherwise it is immediate, and so is the evidence it gives, which
 *   the theory is rebuilt with.
 * - Naming and the constraint-to-LawId map: every native object's installed identifier, minted at the naming door
 *   from its identity, and for each table constraint every law it discharges; a law column reports no violation, and
 *   an unnamed native has no identifier to report. A primary key native is the relation's declared primary key, which
 *   ownership named. A generated CHECK is named for its table and the law it specializes (identity.generatedCheck), so
 *   a law states one CHECK per table, the conjunction of every row condition it states there. A native object that
 *   discharges several laws is one object listing them all; its violation reports the first, a key law's when one
 *   plans it, since key laws are merged first, and a family axis's former's.
 * - The DAG: the theory's violation queries plus each generated CHECK's predicate and each generated law column's
 *   value.
 *
 * The law model of an owned schema, or the first refusal: a theory refusal, a law shape the compiler does not
 * admit (UnsupportedLawFamily), a law over a derived relation (LawOnDerived) or an unrepresentable key. A first
 * normalization settles foreign key deferral, and the second rebuilds the theory with the immediate evidence that
 * deferral gives. */
export const compileLaws = (owned: Owned): Result.Result<LawModel, CompileError> =>
	Result.flatMap(checkedSchema(owned), (checked) =>
		Result.flatMap(buildTheory(checked, provisionalTheory), (first) =>
			Result.flatMap(specialize(first, checked), (model) =>
				Result.flatMap(
					buildTheory(checked, {
						containmentContext: (law) =>
							model.immediate.has(law.id) ? "immediate" : "committedSnapshot"
					}),
					(theory) => specialize(theory, checked)
				)
			)
		)
	)
